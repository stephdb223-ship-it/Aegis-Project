"""Bounded release audit runner for the Aegis reference implementation."""
from __future__ import annotations
import hashlib, json, os, subprocess, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TIMEOUT = int(os.environ.get("AEGIS_AUDIT_TIMEOUT", "60"))
EXCLUDE_DIRS = {".git", ".pytest_cache", "__pycache__", "*.egg-info"}
EXCLUDE_FILES = {"audit-results.json", "release-assurance.json", "evidence-manifest.json"}

def artifact_hash() -> str:
    h = hashlib.sha256()
    files = []
    for p in ROOT.rglob("*"):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if any(part in {".git", ".pytest_cache", "__pycache__"} or part.endswith(".egg-info") for part in rel.parts):
            continue
        if rel.name.endswith((".pyc", ".pyo")) or rel.name in EXCLUDE_FILES:
            continue
        files.append(rel)
    for rel in sorted(files):
        data = (ROOT / rel).read_bytes()
        h.update(str(rel).replace("\\", "/").encode())
        h.update(b"\0")
        h.update(data)
        h.update(b"\0")
    return h.hexdigest()

def run(label, cmd):
    start = time.monotonic()
    try:
        p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=TIMEOUT)
        elapsed = time.monotonic() - start
        print(p.stdout, end="")
        if p.stderr:
            print(p.stderr, end="", file=sys.stderr)
        status = "PASS" if p.returncode == 0 else "FAIL"
        print(f"[{status}] {label} ({elapsed:.2f}s)")
        return p.returncode == 0, elapsed
    except subprocess.TimeoutExpired:
        print(f"[TIMEOUT] {label} (>{TIMEOUT}s)")
        return False, float(TIMEOUT)

def main():
    results = {}
    ok, elapsed = run("test suite", [sys.executable, "-m", "pytest", "-q"])
    results["tests"] = {"status": "PASS" if ok else "FAIL/TIMEOUT", "seconds": round(elapsed, 3)}
    ok2, elapsed2 = run("bytecode compilation", [sys.executable, "-m", "compileall", "-q", "aegis", "audit.py", "release_checks.py"])
    results["compile"] = {"status": "PASS" if ok2 else "FAIL/TIMEOUT", "seconds": round(elapsed2, 3)}
    ok3, elapsed3 = run("release integrity", [sys.executable, "release_checks.py"])
    results["release_integrity"] = {"status": "PASS" if ok3 else "FAIL/TIMEOUT", "seconds": round(elapsed3, 3)}
    ok4, elapsed4 = run("release assurance", [sys.executable, "release_assurance.py", "--skip-clean"])
    results["release_security"] = {}
    ok5, elapsed5 = run("release security hygiene", [sys.executable, "release_security.py"])
    results["release_security"] = {"status": "PASS" if ok5 else "FAIL/TIMEOUT", "seconds": round(elapsed5, 3)}
    results["release_assurance"] = {"status": "PASS" if ok4 else "FAIL/TIMEOUT", "seconds": round(elapsed4, 3)}
    digest = artifact_hash()
    results["artifact_tree_sha256"] = digest
    out = ROOT / "audit-results.json"
    out.write_text(json.dumps(results, indent=2) + "\n")
    print(f"[PASS] artifact tree sha256: {digest}")
    return 0 if ok and ok2 and ok3 and ok4 and ok5 else 1

if __name__ == "__main__":
    raise SystemExit(main())
