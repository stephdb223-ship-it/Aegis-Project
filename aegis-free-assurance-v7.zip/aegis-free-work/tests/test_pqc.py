import pytest
from aegis.pqc import PQCRegistry, PQCProviderError, TestPQCProvider
from aegis import Aegis, AegisError


def test_test_provider_round_trip_and_domain_separation():
    p=TestPQCProvider(); msg=b"authorization"
    sig=p.sign(msg)
    assert p.verify(msg,sig)
    assert not p.verify(b"policy",sig)


def test_registry_rejects_duplicates_and_missing_provider():
    r=PQCRegistry(); p=TestPQCProvider(); r.register(p)
    with pytest.raises(PQCProviderError): r.register(p)
    with pytest.raises(PQCProviderError): r.require("missing")


def test_reference_provider_is_not_misrepresented_as_production():
    r=PQCRegistry(); r.register(TestPQCProvider())
    assert not r.production_ready("test-pqc")


def test_aegis_requires_explicit_pqc_provider_for_external_use():
    a=Aegis(); a.register_identity("alice")
    # The core may represent the PQC policy state, but a production provider
    # must be supplied separately; this test documents that boundary.
    a.set_policy({"read"}, "pqc")
    assert a.store.read().crypto_level == "pqc"
