from aegis.stateful import StatefulCampaign


def test_stateful_campaigns_are_deterministic_and_safe():
    for seed in range(20):
        c = StatefulCampaign(seed)
        assert c.run(200) == 200


def test_long_campaign():
    c = StatefulCampaign(0xA3615)
    assert c.run(2000) == 2000
