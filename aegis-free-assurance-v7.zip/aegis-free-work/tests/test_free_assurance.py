from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_spdx_sbom_matches_lockfile():
    lock = ROOT / "requirements-lock.txt"
    sbom = json.loads((ROOT / "sbom.spdx.json").read_text())
    locked = {line.split("==", 1)[0] for line in lock.read_text().splitlines() if line and not line.startswith("#") and "==" in line}
    listed = {p["name"] for p in sbom["packages"]}
    assert listed == locked
    assert sbom["spdxVersion"] == "SPDX-2.3"


def test_scorecard_action_is_pinned():
    text = (ROOT / ".github/workflows/security.yml").read_text()
    assert "ossf/scorecard-action@2d1146689b8cda280b9bc96326124645441f03bc" in text
    assert "github/codeql-action/upload-sarif@f205ea1c3313d32999d8d6a48b4f6530d4437b38" in text
