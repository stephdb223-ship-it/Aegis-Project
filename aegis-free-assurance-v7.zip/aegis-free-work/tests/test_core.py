import pytest
from aegis import Aegis, AuthorizationDenied
from aegis.model import Operation


def setup():
    a=Aegis(); a.register_identity('alice'); a.set_policy({'read'},'classical'); a.issue_capability('cap','alice','r',{'read'}); return a

def op(a, oid='1', crypto='classical'):
    s=a.store.read(); return Operation(oid,'alice','cap','r','read',s.epoch,crypto)

def test_authorize_and_replay():
    a=setup(); a.authorize(op(a));
    with pytest.raises(AuthorizationDenied): a.authorize(op(a))

def test_revocation_invalidates():
    a=setup(); a.revoke_identity('alice')
    with pytest.raises(AuthorizationDenied): a.authorize(op(a))

def test_policy_blocks():
    a=setup(); a.set_policy({'write'},'classical')
    with pytest.raises(AuthorizationDenied): a.authorize(op(a))

def test_pqc_migration_and_downgrade_block():
    a=setup(); a.migrate_crypto('pqc'); assert a.store.read().crypto_level=='pqc'
    with pytest.raises(Exception): a.migrate_crypto('classical')

def test_delegation_attenuates():
    a=setup(); a.issue_capability('child','alice','r',{'read'},max_depth=1,parent='cap')
    with pytest.raises(Exception): a.issue_capability('bad','alice','r',{'read'},max_depth=1,parent='child')
