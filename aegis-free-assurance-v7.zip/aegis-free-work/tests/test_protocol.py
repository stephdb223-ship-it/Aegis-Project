import json
import pytest
from aegis.distributed import Commit, Statement
from aegis.protocol import encode_statement, decode_statement, encode_commit, decode_commit, message_id, MAX_MESSAGE_BYTES
from aegis.quorum import Quorum, make_certificate


def test_statement_round_trip_is_canonical():
    s = Statement("r1", 4, 2, "abc")
    wire = encode_statement(s)
    assert decode_statement(wire) == s
    assert wire == encode_statement(decode_statement(wire))


def test_commit_round_trip_and_deterministic_signer_order():
    q = Quorum(frozenset({"r1", "r2", "r3"}), 2)
    cert = make_certificate(4, 2, "td", {"r2", "r1"}, q)
    c = Commit(cert, "sd")
    wire = encode_commit(c)
    assert decode_commit(wire) == c
    assert wire == encode_commit(decode_commit(wire))


def test_rejects_noncanonical_json_and_duplicate_key():
    raw = b'{"type":"statement", "version":1, "signer":"r1", "state_version":1,"epoch":0,"transition_digest":"x"}'
    with pytest.raises(ValueError, match="non-canonical"):
        decode_statement(raw)
    dup = b'{"type":"statement","version":1,"signer":"r1","signer":"r2","state_version":1,"epoch":0,"transition_digest":"x"}'
    with pytest.raises(ValueError):
        decode_statement(dup)


def test_rejects_wrong_types_and_extra_fields():
    obj = {"type":"statement","version":1,"signer":"r1","state_version":True,"epoch":0,"transition_digest":"x"}
    with pytest.raises(ValueError): decode_statement(json.dumps(obj, separators=(",", ":"), sort_keys=True).encode())
    obj["state_version"] = 1; obj["extra"] = 1
    with pytest.raises(ValueError): decode_statement(json.dumps(obj, separators=(",", ":"), sort_keys=True).encode())


def test_message_id_is_exact_wire_hash_and_size_bounded():
    wire = encode_statement(Statement("r1", 1, 0, "x"))
    assert message_id(wire) == message_id(wire)
    with pytest.raises(ValueError): message_id(b"x" * (MAX_MESSAGE_BYTES + 1))


def test_rejects_unsorted_or_duplicate_signers():
    base = {"type":"commit","version":1,"certificate":{"state_version":1,"epoch":0,"transition_digest":"x","signers":["r2","r1"],"membership_digest":"m"},"state_digest":"s"}
    raw = json.dumps(base, sort_keys=True, separators=(",", ":")).encode()
    with pytest.raises(ValueError, match="canonical signer order"): decode_commit(raw)
    base["certificate"]["signers"] = ["r1", "r1"]
    raw = json.dumps(base, sort_keys=True, separators=(",", ":")).encode()
    with pytest.raises(ValueError, match="signer set"): decode_commit(raw)


def test_rejects_unsupported_protocol_versions():
    obj = {"type":"statement","version":2,"signer":"r1","state_version":1,"epoch":0,"transition_digest":"x"}
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    with pytest.raises(ValueError, match="unsupported protocol version"):
        decode_statement(raw)


def test_protocol_version_is_part_of_the_canonical_wire_format():
    s = Statement("r1", 1, 0, "x")
    wire = encode_statement(s)
    obj = json.loads(wire)
    assert obj["version"] == 1
    obj["version"] = 0
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    with pytest.raises(ValueError, match="unsupported protocol version"):
        decode_statement(raw)


def test_commit_version_is_strictly_validated():
    q = Quorum(frozenset({"r1", "r2", "r3"}), 2)
    cert = make_certificate(4, 2, "td", {"r1", "r2"}, q)
    wire = encode_commit(Commit(cert, "sd"))
    obj = json.loads(wire)
    obj["version"] = 99
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    with pytest.raises(ValueError, match="unsupported protocol version"):
        decode_commit(raw)
