import multiprocessing as mp
import os
import time
from pathlib import Path

from aegis.auditlog import AuditLog
from aegis.model import SecurityState
from aegis.persistent import DurableStore
from aegis.store import Conflict


def _commit_worker(path: str, increments: int, result_q):
    store = DurableStore(path)
    successes = 0
    try:
        for _ in range(increments):
            for _attempt in range(50):
                current = store.read()
                candidate = SecurityState(version=current.version + 1, epoch=current.epoch,
                                          policy=current.policy, crypto_level=current.crypto_level,
                                          identities=current.identities, capabilities=current.capabilities,
                                          consumed_ops=current.consumed_ops, branch=current.branch,
                                          quarantined=current.quarantined)
                try:
                    store.commit(current.version, candidate)
                    successes += 1
                    break
                except Conflict:
                    time.sleep(0.001)
            else:
                result_q.put(False)
                return
    finally:
        store.close()
    result_q.put(successes == increments)


def _audit_worker(path: str, prefix: str, count: int, result_q):
    log = AuditLog(path)
    try:
        for i in range(count):
            log.append("worker.event", {"worker": prefix, "index": i})
        result_q.put(True)
    except Exception:
        result_q.put(False)


def _crash_after_commit(path: str):
    store = DurableStore(path)
    current = store.read()
    candidate = SecurityState(version=current.version + 1, epoch=current.epoch,
                              policy=current.policy, crypto_level=current.crypto_level,
                              identities=current.identities, capabilities=current.capabilities,
                              consumed_ops=current.consumed_ops, branch=current.branch,
                              quarantined=current.quarantined)
    store.commit(current.version, candidate)
    os._exit(0)


def _ctx():
    return mp.get_context("spawn")


def test_multiple_processes_cas_retry_to_single_monotonic_state(tmp_path):
    path = str(tmp_path / "state.db")
    DurableStore(path).close()
    ctx = _ctx()
    q = ctx.Queue()
    workers = [ctx.Process(target=_commit_worker, args=(path, 12, q)) for _ in range(4)]
    for p in workers:
        p.start()
    for p in workers:
        p.join(15)
        assert p.exitcode == 0
    assert all(q.get(timeout=2) for _ in workers)
    store = DurableStore(path)
    try:
        assert store.read().version == 48
    finally:
        store.close()


def test_process_crash_after_durable_commit_recovers_cleanly(tmp_path):
    path = str(tmp_path / "state.db")
    DurableStore(path).close()
    p = _ctx().Process(target=_crash_after_commit, args=(path,))
    p.start()
    p.join(10)
    assert p.exitcode == 0
    store = DurableStore(path)
    try:
        assert store.read().version == 1
    finally:
        store.close()


def test_multiprocess_audit_appends_remain_a_valid_chain(tmp_path):
    path = str(tmp_path / "audit.jsonl")
    ctx = _ctx()
    q = ctx.Queue()
    workers = [ctx.Process(target=_audit_worker, args=(path, f"w{i}", 15, q)) for i in range(4)]
    for p in workers:
        p.start()
    for p in workers:
        p.join(15)
        assert p.exitcode == 0
    assert all(q.get(timeout=2) for _ in workers)
    log = AuditLog(path)
    assert log.verify()
    assert sum(1 for _ in Path(path).open("rb")) == 60
