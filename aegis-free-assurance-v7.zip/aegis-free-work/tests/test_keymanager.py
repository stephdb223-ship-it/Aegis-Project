import pytest
from aegis import Aegis
from aegis.keymanager import InMemoryKeyManager, KeyManagerError


def test_external_key_manager_keeps_private_material_out_of_state():
    km=InMemoryKeyManager(); a=Aegis(key_manager=km)
    a.register_identity("alice")
    ident=a.store.read().identities[0]
    assert len(ident.key)==32
    assert km.active_version("alice")==1


def test_sign_rotate_and_destroy_lifecycle():
    km=InMemoryKeyManager(); h,pub=km.generate("alice")
    sig=km.sign(h,b"payload")
    assert len(sig)==64
    h2,pub2=km.rotate("alice")
    assert h2.version==2 and pub2 != pub
    assert km.sign(h2,b"payload") != sig
    km.destroy("alice")
    with pytest.raises(KeyManagerError): km.sign(h2,b"payload")


def test_invalid_handle_and_duplicate_are_rejected():
    km=InMemoryKeyManager(); km.generate("alice")
    with pytest.raises(KeyManagerError): km.generate("alice")
    with pytest.raises(KeyManagerError): km.sign(type("H",(),{"key_id":"alice","version":9})(), b"x")
