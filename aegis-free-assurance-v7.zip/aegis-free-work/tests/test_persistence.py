from pathlib import Path
import pytest
from aegis import Aegis
from aegis.core import AuthorizationDenied
from aegis.model import Operation
from aegis.persistent import DurableStore
from aegis.store import Conflict


def configured(path):
    a=Aegis(DurableStore(path)); a.register_identity('alice'); a.set_policy({'read'}, 'classical')
    a.issue_capability('cap','alice','doc',{'read'})
    return a

def make_op(a, oid):
    s=a.store.read(); return Operation(oid,'alice','cap','doc','read',s.epoch,s.crypto_level)

def test_state_survives_reopen(tmp_path):
    p=tmp_path/'state.db'; a=configured(p); ev=a.authorize(make_op(a,'one')); a.store.close()
    b=Aegis(DurableStore(p)); s=b.store.read()
    assert ev.state_version==s.version and 'one' in s.consumed_ops
    with pytest.raises(AuthorizationDenied): b.authorize(make_op(b,'one'))
    b.store.close()

def test_stale_version_cannot_overwrite_durable_state(tmp_path):
    p=tmp_path/'state.db'; a=configured(p); s=a.store.read()
    b=Aegis(DurableStore(p));
    with pytest.raises(Conflict): b.store.commit(s.version-1, s)
    b.store.close(); a.store.close()

def test_failed_commit_leaves_previous_state(tmp_path):
    p=tmp_path/'state.db'; a=configured(p); s=a.store.read()
    bad=type(s)(version=s.version+2, epoch=s.epoch, policy=s.policy, crypto_level=s.crypto_level,
                identities=s.identities, capabilities=s.capabilities, consumed_ops=s.consumed_ops,
                branch=s.branch, quarantined=s.quarantined)
    with pytest.raises(Conflict): a.store.commit(s.version,bad)
    assert a.store.read()==s
    a.store.close()

def test_recovery_after_policy_and_epoch_changes(tmp_path):
    p=tmp_path/'state.db'; a=configured(p); a.revoke_identity('alice'); a.store.close()
    b=Aegis(DurableStore(p)); s=b.store.read()
    assert s.epoch==1 and s.identities[0].revoked
    b.store.close()
