from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace

from aegis.auditlog import AuditLog
from aegis.keymanager import InMemoryKeyManager
from aegis.persistent import DurableStore
from aegis.store import AtomicStore, Conflict


def test_atomic_store_allows_only_one_winner_per_version():
    store = AtomicStore()
    base = store.read()
    states = [replace(base, version=base.version + 1, branch=str(i)) for i in range(24)]
    def attempt(state):
        try:
            store.commit(base.version, state)
            return True
        except Conflict:
            return False
    with ThreadPoolExecutor(max_workers=24) as pool:
        results = list(pool.map(attempt, states))
    assert sum(results) == 1
    assert store.read().version == 1


def test_durable_store_serializes_same_instance_writers(tmp_path):
    store = DurableStore(tmp_path / "state.db")
    def writer(i):
        # Deliberately race stale reads; exactly one CAS winner per observed version.
        while True:
            s = store.read()
            ns = replace(s, version=s.version + 1, branch=f"t{i}")
            try:
                store.commit(s.version, ns)
                return
            except Conflict:
                continue
    with ThreadPoolExecutor(max_workers=12) as pool:
        list(pool.map(writer, range(12)))
    assert store.read().version == 12
    store.close()


def test_audit_log_concurrent_append_preserves_chain(tmp_path):
    log = AuditLog(str(tmp_path / "audit.jsonl"))
    def append(i):
        return log.append("concurrent", {"i": i})
    with ThreadPoolExecutor(max_workers=16) as pool:
        records = list(pool.map(append, range(100)))
    assert sorted(r.sequence for r in records) == list(range(1, 101))
    assert log.verify()


def test_key_manager_concurrent_signing_is_stable():
    km = InMemoryKeyManager()
    handle, public = km.generate("k")
    payload = b"same payload"
    with ThreadPoolExecutor(max_workers=16) as pool:
        sigs = list(pool.map(lambda _: km.sign(handle, payload), range(100)))
    assert len(set(sigs)) == 1
    assert km.verify_key(handle) == public
