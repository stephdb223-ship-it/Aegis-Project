from aegis.endurance import DeterministicEndurance, SequenceMinimizer
from aegis.stateful import StatefulCampaign


def test_endurance_trace_is_reproducible():
    a = DeterministicEndurance(0xA3615E)
    b = DeterministicEndurance(0xA3615E)
    labels = ("authorize", "revoke", "migrate", "replay", "quorum")
    for _ in range(10000):
        assert a.choose(labels) == b.choose(labels)
    assert a.digest_history() == b.digest_history()


def test_sequence_minimizer_reduces_to_small_reproducer():
    bad = ["noise"] * 20 + ["A", "noise", "B"] + ["noise"] * 20
    def fails(seq):
        return "A" in seq and "B" in seq and seq.index("A") < seq.index("B")
    result = SequenceMinimizer(fails).minimize(bad)
    assert result == ["A", "B"]


def test_large_stateful_campaign_reproducible():
    # Two independent 50k-step runs must converge on the same deterministic trace.
    a = StatefulCampaign(0xAE615EED)
    b = StatefulCampaign(0xAE615EED)
    assert a.run(50_000) == 50_000
    assert b.run(50_000) == 50_000
    a.assert_safety(); b.assert_safety()
    assert a.history == b.history
