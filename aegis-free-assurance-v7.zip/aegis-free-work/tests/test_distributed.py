import pytest
from aegis.distributed import DistributedSimulator, Commit
from aegis.crypto import digest


def test_partition_below_threshold_does_not_create_certificate():
    d=DistributedSimulator({'a','b','c','d','e'},3)
    with pytest.raises(ValueError):
        d.certificate(1,0,'t',{'a','b'})


def test_duplicate_delivery_is_idempotent():
    d=DistributedSimulator({'a','b','c'},2)
    cert=d.certificate(1,0,'t',{'a','b'})
    c=Commit(cert,digest('state','1'))
    assert d.broadcast(c)==3
    assert d.broadcast(c)==3
    assert all(len(r.committed)==1 for r in d.replicas.values())


def test_reordered_delivery_preserves_single_final_value():
    d=DistributedSimulator({'a','b','c'},2)
    c1=Commit(d.certificate(1,0,'alpha',{'a','b'}), digest('alpha'))
    c2=Commit(d.certificate(2,0,'beta',{'b','c'}), digest('beta'))
    d.broadcast(c2, {'a','b','c'})
    d.broadcast(c1, {'a','b','c'})
    assert all([r.committed[-1].certificate.state_version==2 for r in d.replicas.values()])


def test_equivocation_is_detected_and_cannot_certify():
    d=DistributedSimulator({'a','b','c'},2)
    d.statement('a',1,0,'alpha')
    d.statement('a',1,0,'evil')
    assert 'a' in d.equivocations
    with pytest.raises(ValueError):
        d.certificate(1,0,'evil',{'a','b'})


def test_valid_quorum_commit_converges():
    d=DistributedSimulator({'a','b','c','d'},3)
    cert=d.certificate(7,2,'transition-7',{'a','b','c'})
    c=Commit(cert,digest('state','7'))
    assert d.broadcast(c)==4
    assert len(set(d.finality(7,2).values()))==1
    assert next(iter(d.finality(7,2).values()))=='transition-7'
