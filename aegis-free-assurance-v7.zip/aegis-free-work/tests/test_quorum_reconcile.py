from aegis.quorum import Quorum,make_certificate,verify_certificate
from aegis.reconcile import Branch,choose

def test_quorum_certificate():
    q=Quorum(frozenset({'a','b','c'}),2); c=make_certificate(2,3,'x',{'a','b'},q); assert verify_certificate(c,q)

def test_quorum_rejects_unknown_signer():
    q=Quorum(frozenset({'a','b','c'}),2)
    try: make_certificate(2,3,'x',{'a','z'},q); assert False
    except ValueError: pass

def test_reconcile_deterministic():
    bs=[Branch('b','r',4,2,'x'),Branch('a','r',4,2,'y')]; w,l=choose(bs,2); assert w.branch_id=='a' and l==('b',)
