import pytest
from aegis.upgrade import ReleaseVersion, StateEnvelope, UpgradeError, UpgradeGuard, migrate_state, validate_upgrade

def env(schema=1, release="1.0.0", state=10):
    return StateEnvelope(schema, ReleaseVersion.parse(release), state)

def test_release_version_order_and_parse():
    assert ReleaseVersion.parse("1.2.3") < ReleaseVersion.parse("1.2.4")
    with pytest.raises(UpgradeError): ReleaseVersion.parse("1.2")

def test_upgrade_is_monotonic():
    validate_upgrade(env(), env(2, "1.1.0", 11))
    with pytest.raises(UpgradeError): validate_upgrade(env(), env(1, "0.9.0", 10))
    with pytest.raises(UpgradeError): validate_upgrade(env(), env(1, "1.1.0", 9))
    with pytest.raises(UpgradeError): validate_upgrade(env(), env(3, "2.0.0", 11))

def test_guard_advances_only_after_validation():
    g = UpgradeGuard(env())
    assert g.approve(env(2, "1.1.0", 11)).schema_version == 2
    with pytest.raises(UpgradeError): g.approve(env(2, "1.0.9", 12))
    assert g.current.release == ReleaseVersion.parse("1.1.0")

def test_migration_is_single_step_and_fail_closed():
    fn = {1: lambda d: {**d, "new": True}}
    assert migrate_state({"x": 1}, 1, 2, fn)["new"] is True
    with pytest.raises(UpgradeError): migrate_state({}, 1, 3, fn)
    with pytest.raises(UpgradeError): migrate_state({}, 1, 2, {})

def test_migration_output_must_be_mapping():
    with pytest.raises(UpgradeError): migrate_state({}, 1, 2, {1: lambda d: []})
