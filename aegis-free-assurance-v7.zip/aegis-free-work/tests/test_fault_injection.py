import json, sqlite3
import pytest
from aegis.fault import FaultInjector, FaultPlan, InjectedFault
from aegis.auditlog import AuditLog
from aegis.persistent import DurableStore
from aegis.model import SecurityState
from aegis.recovery import StartupRecoveryGate, RecoveryError
from aegis.deployment import DeploymentConfig

def test_fault_plan_is_deterministic():
    f = FaultInjector(FaultPlan({'commit.after_begin'}))
    f.hit('commit.before')
    assert f.hits == ['commit.before']
    with pytest.raises(InjectedFault):
        f.hit('commit.after_begin')
    assert f.hits[-1] == 'commit.after_begin'

def test_interrupted_audit_append_never_pretends_success(tmp_path):
    log = AuditLog(str(tmp_path/'audit.jsonl'))
    # Simulate a crash before append by injecting at the caller boundary.
    f = FaultInjector(FaultPlan({'audit.before_append'}))
    with pytest.raises(InjectedFault):
        f.hit('audit.before_append')
        log.append('would_not_happen', {'x': 1})
    assert log.verify()

def test_truncated_audit_is_rejected(tmp_path):
    p = tmp_path/'audit.jsonl'; log=AuditLog(str(p))
    log.append('a', {'x':1}); log.append('b', {'x':2})
    raw=p.read_bytes(); p.write_bytes(raw[:-3])
    assert not log.verify()
    store=DurableStore(str(tmp_path/'state.db'), SecurityState())
    cfg=DeploymentConfig(environment='development', bind_host='127.0.0.1', bind_port=8080, audit_log=str(p), max_request_bytes=65536, request_timeout_ms=5000, require_tls=False, allow_debug=False)
    with pytest.raises(RecoveryError): StartupRecoveryGate(store,log,cfg).validate()
    store.close()

def test_db_commit_is_atomic_when_process_stops_before_commit(tmp_path):
    p=tmp_path/'state.db'; s=DurableStore(str(p), SecurityState())
    old=s.read(); new=SecurityState(version=old.version+1, epoch=old.epoch, policy=old.policy, crypto_level=old.crypto_level, identities=old.identities, capabilities=old.capabilities, consumed_ops=old.consumed_ops, branch=old.branch, quarantined=old.quarantined)
    # BEGIN without COMMIT models a crash at the transaction boundary.
    s._db.execute('BEGIN IMMEDIATE')
    s._db.execute('UPDATE aegis_state SET version=?, payload=? WHERE id=1', (new.version, b'not-committed'))
    s._db.execute('ROLLBACK'); s.close()
    reopened=DurableStore(str(p)); assert reopened.read().version == old.version; reopened.close()

def test_fault_campaign_covers_cross_module_boundaries():
    points=['authorize.before_commit','commit.after_begin','audit.before_append','replica.before_accept','upgrade.before_swap']
    f=FaultInjector(FaultPlan(points));
    for p in points:
        with pytest.raises(InjectedFault): f.hit(p)
    assert f.hits == points
