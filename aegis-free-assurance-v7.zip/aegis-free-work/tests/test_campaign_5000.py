from aegis.stateful import StatefulCampaign


def test_5000_step_adversarial_campaign_is_safe_and_deterministic():
    """Run the release-gate 5,000-step deterministic adversarial campaign.

    The harness asserts safety after every generated event. Running the same
    seed twice must produce the same trace length, making the campaign
    reproducible for audit and regression purposes.
    """
    seed = 0xA3615_5000
    first = StatefulCampaign(seed)
    second = StatefulCampaign(seed)

    assert first.run(5000) == 5000
    assert second.run(5000) == 5000
    assert first.history == second.history
