import threading
import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from aegis import Aegis, AuthorizationDenied
from aegis.model import Operation
from aegis.crypto import sign_context, verify_context
from aegis.store import AtomicStore, Conflict
from aegis.model import SecurityState


def setup():
    a=Aegis(); a.register_identity('alice'); a.set_policy({'read'},'classical'); a.issue_capability('cap','alice','r',{'read'}); return a

def test_context_bound_signature():
    k=Ed25519PrivateKey.generate(); pub=k.public_key(); sig=sign_context(k,'capability',b'payload')
    assert verify_context(pub,'capability',b'payload',sig)
    assert not verify_context(pub,'policy',b'payload',sig)

def test_atomic_store_rejects_stale_commit():
    s=SecurityState(); st=AtomicStore(s)
    from dataclasses import replace
    ns=replace(s,version=1)
    st.commit(0,ns)
    with pytest.raises(Conflict): st.commit(0,replace(ns,version=2))

def test_concurrent_unique_ops():
    a=setup(); successes=[]
    def worker(i):
        s=a.store.read(); op=Operation(f'op-{i}','alice','cap','r','read',s.epoch,'classical')
        try: a.authorize(op); successes.append(i)
        except AuthorizationDenied: pass
    ts=[threading.Thread(target=worker,args=(i,)) for i in range(20)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert len(successes)==20

def test_same_op_is_single_use_under_race():
    a=setup(); successes=[]
    def worker():
        s=a.store.read(); op=Operation('same','alice','cap','r','read',s.epoch,'classical')
        try: a.authorize(op); successes.append(1)
        except AuthorizationDenied: pass
    ts=[threading.Thread(target=worker) for _ in range(10)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert len(successes)==1
