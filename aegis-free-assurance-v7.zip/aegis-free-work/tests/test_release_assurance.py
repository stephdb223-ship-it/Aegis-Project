from pathlib import Path
import hashlib
from release_assurance import tree_digest, check_lock

ROOT = Path(__file__).resolve().parents[1]

def test_required_release_inputs_exist():
    for name in ("pyproject.toml", "requirements-lock.txt", "README.md", "audit.py", "release_checks.py"):
        assert (ROOT / name).is_file()

def test_lock_is_exactly_pinned():
    assert check_lock()["all_pinned"]

def test_tree_digest_is_deterministic():
    assert tree_digest() == tree_digest()

def test_no_untracked_bytecode_in_release_tree():
    bad = [p for p in ROOT.rglob("*") if p.is_file() and p.suffix in {".pyc", ".pyo"} and "__pycache__" not in p.parts]
    assert not bad
