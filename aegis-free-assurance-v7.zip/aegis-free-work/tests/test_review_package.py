from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_review_package_documents_exist():
    for name in [
        "REVIEW_PACKAGE.md",
        "ATTACK_SURFACE.md",
        "SECURITY_TRACEABILITY.md",
        "REVIEW_PROCEDURE.md",
        "EVIDENCE_INDEX.json",
    ]:
        assert (ROOT / name).is_file(), name


def test_evidence_index_preserves_external_gates():
    data = json.loads((ROOT / "EVIDENCE_INDEX.json").read_text())
    gates = data["external_gates"]
    assert gates["independent_security_review"] == "PENDING"
    assert gates["deployment_validation"] == "PENDING"
    assert gates["certification"] == "PENDING"


def test_traceability_has_required_security_surfaces():
    text = (ROOT / "SECURITY_TRACEABILITY.md").read_text()
    for phrase in ["Replay", "Quorum", "Equivocation", "Reconciliation", "PQC", "Release"]:
        assert phrase in text
