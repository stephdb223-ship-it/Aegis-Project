import threading
import pytest
from aegis import Aegis
from aegis.model import Operation
from aegis.quorum import Quorum, make_certificate, verify_certificate
from aegis.reconcile import Branch, choose, branch_digest
from aegis.core import AuthorizationDenied, AegisError


def configured():
    a=Aegis(); a.register_identity('alice'); a.set_policy({'read'}, 'classical')
    a.issue_capability('cap','alice','doc',{'read'})
    return a

def op(a, n):
    s=a.store.read()
    return Operation(n,'alice','cap','doc','read',s.epoch,s.crypto_level)

def test_replay_is_atomic_under_race():
    a=configured(); o=op(a,'race'); results=[]
    def run():
        try: a.authorize(o); results.append('ok')
        except AuthorizationDenied: results.append('deny')
    ts=[threading.Thread(target=run) for _ in range(32)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert results.count('ok')==1 and len(results)==32

def test_quorum_threshold_bounds_and_context_binding():
    with pytest.raises(ValueError): Quorum(frozenset({'a'}),0)
    with pytest.raises(ValueError): Quorum(frozenset({'a'}),2)
    q=Quorum(frozenset({'a','b','c'}),2)
    c=make_certificate(1,0,'tx',{'a','b'},q)
    assert verify_certificate(c,q)
    q2=Quorum(frozenset({'a','b','d'}),2)
    assert not verify_certificate(c,q2)

def test_certificate_rejects_malformed_fields():
    q=Quorum(frozenset({'a','b'}),2)
    with pytest.raises(ValueError): make_certificate(0,0,'tx',{'a','b'},q)
    with pytest.raises(ValueError): make_certificate(1,-1,'tx',{'a','b'},q)
    assert not verify_certificate(type('C',(),dict(state_version=0,epoch=0,transition_digest='tx',signers=frozenset({'a','b'}),membership_digest='x'))(),q)

def test_reconciliation_rejects_duplicate_or_malformed_branches():
    b=Branch('b','p',1,0,'tx')
    with pytest.raises(ValueError): choose([b,b],0)
    with pytest.raises(ValueError): choose([Branch('x','',1,0,'tx')],0)
    assert branch_digest(b)

def test_reconciliation_prefers_highest_version_deterministically():
    bs=[Branch('b','p',3,0,'btx'),Branch('a','p',3,0,'atx'),Branch('c','p',2,0,'ctx')]
    winner, losers=choose(bs,0)
    assert winner.branch_id=='a'
    assert losers==('b','c')

def test_revocation_invalidates_old_capability_epoch():
    a=configured(); a.revoke_identity('alice')
    with pytest.raises(AuthorizationDenied): a.authorize(op(a,'after-revoke'))
    with pytest.raises(AegisError): a.issue_capability('new','alice','doc',{'read'})
