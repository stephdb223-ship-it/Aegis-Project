from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_github_assurance_artifacts_are_present():
    required = [
        ".github/workflows/security.yml",
        ".github/CODEOWNERS",
        "SECURITY.md",
        "CONTRIBUTING.md",
        "GITHUB_HARDENING_CHECKLIST.md",
        "OSPS_BASELINE_ASSESSMENT.md",
        "sbom.spdx.json",
    ]
    missing = [p for p in required if not (ROOT / p).is_file()]
    assert not missing, f"missing repository assurance artifacts: {missing}"


def test_scorecard_action_is_immutable_pinned():
    workflow = (ROOT / ".github/workflows/security.yml").read_text()
    assert "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1" in workflow
    assert "actions/setup-python@5fda3b95a4ea91299a34e894583c3862153e4b97" in workflow
    assert "ossf/scorecard-action@2d1146689b8cda280b9bc96326124645441f03bc" in workflow
    assert "github/codeql-action/upload-sarif@f205ea1c3313d32999d8d6a48b4f6530d4437b38" in workflow


def test_codeowners_has_real_maintainer():
    text = (ROOT / ".github/CODEOWNERS").read_text()
    assert "REPLACE_WITH_AEGIS_MAINTAINER" not in text
    assert "@stephdb223-ship-it" in text
