from review_handoff import validate

def test_review_handoff_is_coherent():
    result = validate()
    assert result["status"] == "PASS", result
