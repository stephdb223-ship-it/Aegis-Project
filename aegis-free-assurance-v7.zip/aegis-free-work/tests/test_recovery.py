import json
import sqlite3
import pytest
from aegis.auditlog import AuditLog
from aegis.deployment import DeploymentConfig
from aegis.persistent import DurableStore
from aegis.recovery import RecoveryError, StartupRecoveryGate


def cfg(path):
    return DeploymentConfig.from_mapping({
        "environment":"staging", "bind_host":"127.0.0.1", "bind_port":8443,
        "audit_log":"audit.jsonl", "require_tls":True, "allow_debug":False,
    })

def test_startup_gate_accepts_consistent_state(tmp_path):
    db=DurableStore(tmp_path/"state.db")
    log=AuditLog(str(tmp_path/"audit.jsonl")); log.append("startup", {"version":0})
    r=StartupRecoveryGate(db, log, cfg(tmp_path/"audit.jsonl")).validate()
    assert r == r.__class__(0, True, True, True)
    db.close()

def test_startup_gate_rejects_tampered_audit(tmp_path):
    db=DurableStore(tmp_path/"state.db")
    p=tmp_path/"audit.jsonl"; log=AuditLog(str(p)); log.append("x", {"a":1})
    raw=p.read_text(); p.write_text(raw.replace('"a":1','"a":2'))
    with pytest.raises(RecoveryError): StartupRecoveryGate(db, log, cfg(p)).validate()
    db.close()

def test_startup_gate_rejects_tampered_database_payload(tmp_path):
    p=tmp_path/"state.db"; db=DurableStore(p); log=AuditLog(str(tmp_path/"audit.jsonl"))
    db._db.execute("UPDATE aegis_state SET payload=? WHERE id=1", (b'{bad',))
    with pytest.raises(RecoveryError): StartupRecoveryGate(db, log, cfg(tmp_path/"audit.jsonl")).validate()
    db.close()

def test_startup_gate_rejects_invalid_config(tmp_path):
    db=DurableStore(tmp_path/"state.db"); log=AuditLog(str(tmp_path/"audit.jsonl"))
    bad=DeploymentConfig("production","127.0.0.1",443,str(tmp_path/"audit.jsonl"),require_tls=False)
    with pytest.raises(RecoveryError): StartupRecoveryGate(db, log, bad).validate()
    db.close()
