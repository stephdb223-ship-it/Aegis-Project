import pytest
from aegis.pqc_openssl import OpenSSLMLDSAProvider, OpenSSLMLKEMProvider, openssl_pqc_available, openssl_kem_available
from aegis.pqc import PQCProviderError

@pytest.mark.skipif(not openssl_pqc_available('ML-DSA-65'), reason='ML-DSA-65 unavailable')
def test_mldsa_context_binding_rejects_wrong_context():
    p = OpenSSLMLDSAProvider(context_string='AEGIS/protocol/v1')
    try:
        msg = b'authorization-state-v1'
        sig = p.sign(msg)
        assert p.verify(msg, sig)
        q = OpenSSLMLDSAProvider(context_string='AEGIS/other-protocol/v1')
        try:
            assert not q.verify(msg, sig)
        finally:
            q.close()
    finally:
        p.close()

@pytest.mark.skipif(not openssl_kem_available('ML-KEM-768'), reason='ML-KEM-768 unavailable')
def test_mlkem_rejects_mutated_ciphertext():
    p = OpenSSLMLKEMProvider()
    try:
        ct, secret = p.encapsulate()
        bad = bytearray(ct)
        bad[len(bad)//2] ^= 1
        try:
            recovered = p.decapsulate(bytes(bad))
        except PQCProviderError:
            return
        assert recovered != secret
    finally:
        p.close()

@pytest.mark.skipif(not openssl_pqc_available('ML-DSA-65'), reason='ML-DSA-65 unavailable')
def test_mldsa_signature_corruption_is_rejected():
    p = OpenSSLMLDSAProvider()
    try:
        msg = b'AEGIS/canonical-event/v1'
        sig = bytearray(p.sign(msg))
        sig[-1] ^= 1
        assert not p.verify(msg, bytes(sig))
    finally:
        p.close()
