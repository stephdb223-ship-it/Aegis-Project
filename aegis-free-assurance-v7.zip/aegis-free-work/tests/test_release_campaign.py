import random
from aegis.crypto import digest
from aegis.stateful import StatefulCampaign

def test_deterministic_campaign_matrix():
    for seed in range(50):
        c = StatefulCampaign(seed)
        assert c.run(400) == 400

def test_digest_stability_corpus():
    rng = random.Random(20260821)
    seen = set()
    for _ in range(5000):
        parts = [str(rng.randrange(1 << 32)) for _ in range(rng.randrange(1, 6))]
        d = digest(*parts)
        assert len(d) == 64
        assert d not in seen
        seen.add(d)
