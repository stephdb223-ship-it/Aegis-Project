from aegis import Aegis
from aegis.invariants import check_state

def test_state_invariants_hold():
    a=Aegis(); a.register_identity('a'); a.set_policy({'read'}); a.issue_capability('c','a','r',{'read'}); assert check_state(a.store.read())
