import pytest
from concurrent.futures import ThreadPoolExecutor
from aegis.pqc import PQCProviderError
from aegis.pqc_openssl import (
    OpenSSLMLDSAProvider, OpenSSLMLKEMProvider,
    openssl_pqc_available, openssl_kem_available,
)


def test_openssl_mldsa_is_available_and_round_trips():
    if not openssl_pqc_available("ML-DSA-65"):
        pytest.skip("OpenSSL ML-DSA-65 unavailable")
    p = OpenSSLMLDSAProvider()
    try:
        msg = b"AEGIS/FIPS-204/context/v1"
        sig = p.sign(msg)
        assert p.verify(msg, sig)
        assert not p.verify(msg + b"!", sig)
        assert not p.production  # OpenSSL availability is not FIPS validation.
        assert p.security_level == 3
    finally:
        p.close()


def test_openssl_mlkem_is_available_and_round_trips():
    if not openssl_kem_available("ML-KEM-768"):
        pytest.skip("OpenSSL ML-KEM-768 unavailable")
    p = OpenSSLMLKEMProvider()
    try:
        ciphertext, secret = p.encapsulate()
        assert len(ciphertext) > 0
        assert len(secret) >= 32
        assert p.decapsulate(ciphertext) == secret
        with pytest.raises(PQCProviderError):
            p.decapsulate(ciphertext[:-1])
    finally:
        p.close()


def test_openssl_pqc_provider_operations_are_concurrency_safe():
    if not openssl_pqc_available("ML-DSA-65") or not openssl_kem_available("ML-KEM-768"):
        pytest.skip("OpenSSL PQC algorithms unavailable")
    signer = OpenSSLMLDSAProvider()
    kem = OpenSSLMLKEMProvider()
    try:
        messages = [f"aegis-concurrent-{i}".encode() for i in range(12)]
        with ThreadPoolExecutor(max_workers=6) as pool:
            signatures = list(pool.map(signer.sign, messages))
        with ThreadPoolExecutor(max_workers=6) as pool:
            checks = list(pool.map(lambda pair: signer.verify(*pair), zip(messages, signatures)))
        assert checks == [True] * len(messages)

        with ThreadPoolExecutor(max_workers=6) as pool:
            pairs = list(pool.map(lambda _: kem.encapsulate(), range(12)))
        with ThreadPoolExecutor(max_workers=6) as pool:
            recovered = list(pool.map(lambda pair: kem.decapsulate(pair[0]), pairs))
        assert recovered == [secret for _, secret in pairs]
    finally:
        signer.close()
        kem.close()
