import random
from aegis import Aegis, AegisError, AuthorizationDenied
from aegis.model import Operation
from aegis.invariants import check_state


def test_10000_malformed_and_boundary_inputs():
    rng = random.Random(0xA3615F00D)
    a = Aegis()
    a.register_identity("alice")
    a.set_policy({"read"}, "classical")
    a.issue_capability("cap", "alice", "r", {"read"})
    actions = ["", "read", "\x00", "A" * 1024, "\ud800"]
    for n in range(10_000):
        s = a.store.read()
        try:
            if n % 5 == 0:
                a.set_policy({rng.choice(actions)}, rng.choice(("classical", "hybrid", "pqc")))
            elif n % 5 == 1:
                a.migrate_crypto(rng.choice(("classical", "hybrid", "pqc", "invalid")))
            elif n % 5 == 2:
                op_id = rng.choice((f"fuzz-{n}", "", "\x00", "A" * rng.randrange(0, 64)))
                op = Operation(op_id, "alice", rng.choice(("cap", "", "missing")), "r", rng.choice(actions), s.epoch, s.crypto_level)
                try:
                    a.authorize(op)
                except (AuthorizationDenied, AegisError):
                    pass
            elif n % 5 == 3:
                op = Operation(f"stale-{n}", "alice", "cap", "r", "read", max(0, s.epoch - 1), "classical")
                try:
                    a.authorize(op)
                except (AuthorizationDenied, AegisError):
                    pass
            else:
                check_state(s)
        except (AegisError, UnicodeError, ValueError, AssertionError):
            pass
        check_state(a.store.read())
