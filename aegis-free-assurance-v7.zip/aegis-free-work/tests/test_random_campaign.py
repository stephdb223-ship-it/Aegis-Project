import random
from aegis import Aegis, AegisError, AuthorizationDenied
from aegis.model import Operation
from aegis.invariants import check_state


def test_10000_step_randomized_safety_campaign():
    rng=random.Random(0xAE615)
    a=Aegis(); a.register_identity("alice"); a.set_policy({"read"},"classical")
    a.issue_capability("cap","alice","r",{"read"})
    for n in range(10000):
        s=a.store.read()
        action=rng.randrange(6)
        try:
            if action==0:
                op=Operation(f"op-{n}","alice","cap","r","read",s.epoch,s.crypto_level)
                a.authorize(op)
            elif action==1:
                op=Operation(f"replay-{n//2}","alice","cap","r","read",s.epoch,s.crypto_level)
                try: a.authorize(op)
                except AuthorizationDenied: pass
            elif action==2:
                a.set_policy({"read"}, rng.choice(["classical","hybrid","pqc"]))
            elif action==3:
                a.migrate_crypto(rng.choice(["classical","hybrid","pqc"]))
            elif action==4:
                # deliberately stale operation
                old=max(0,s.epoch-1)
                op=Operation(f"stale-{n}","alice","cap","r","read",old,"classical")
                try: a.authorize(op)
                except AuthorizationDenied: pass
            else:
                check_state(a.store.read())
        except AegisError:
            pass
        check_state(a.store.read())

def test_20000_step_randomized_safety_campaign():
    rng=random.Random(0xAE61_500)
    a=Aegis(); a.register_identity("alice"); a.set_policy({"read"},"classical")
    a.issue_capability("cap","alice","r",{"read"})
    for n in range(20000):
        s=a.store.read()
        action=rng.randrange(6)
        try:
            if action == 0:
                op=Operation(f"op-{n}","alice","cap","r","read",s.epoch,s.crypto_level)
                a.authorize(op)
            elif action == 1:
                op=Operation(f"replay-{n//2}","alice","cap","r","read",s.epoch,s.crypto_level)
                try: a.authorize(op)
                except AuthorizationDenied: pass
            elif action == 2:
                a.set_policy({"read"}, rng.choice(["classical","hybrid","pqc"]))
            elif action == 3:
                a.migrate_crypto(rng.choice(["classical","hybrid","pqc"]))
            elif action == 4:
                old=max(0,s.epoch-1)
                op=Operation(f"stale-{n}","alice","cap","r","read",old,"classical")
                try: a.authorize(op)
                except AuthorizationDenied: pass
            else:
                check_state(a.store.read())
        except AegisError:
            pass
        check_state(a.store.read())
