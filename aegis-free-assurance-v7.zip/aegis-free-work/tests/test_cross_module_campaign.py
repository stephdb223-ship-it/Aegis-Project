from aegis.cross_module import CrossModuleCampaign


def test_cross_module_campaign_deterministic():
    a = CrossModuleCampaign(0xAE61_5C0)
    b = CrossModuleCampaign(0xAE61_5C0)
    assert a.run(5000) == b.run(5000) == 5000
    for rid in sorted(a.sim.replicas):
        av = [(c.certificate.state_version, c.certificate.transition_digest) for c in a.sim.replicas[rid].committed]
        bv = [(c.certificate.state_version, c.certificate.transition_digest) for c in b.sim.replicas[rid].committed]
        assert av == bv


def test_cross_module_campaign_multiple_seeds():
    for seed in range(12):
        assert CrossModuleCampaign(seed).run(750) == 750
