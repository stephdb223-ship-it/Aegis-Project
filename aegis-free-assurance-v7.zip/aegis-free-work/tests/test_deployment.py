import pytest
from aegis.deployment import DeploymentConfig, DeploymentConfigError, validate_environment

def prod():
    return {"environment":"production","bind_host":"127.0.0.1","bind_port":8443,"audit_log":"/var/log/aegis/audit.jsonl"}

def test_production_config_validates():
    DeploymentConfig.from_mapping(prod())

def test_production_requires_tls_and_no_debug():
    for k,v in (("require_tls",False),("allow_debug",True)):
        raw=prod(); raw[k]=v
        with pytest.raises(DeploymentConfigError): DeploymentConfig.from_mapping(raw)

def test_bounds_and_unknown_keys_rejected():
    raw=prod(); raw["bind_port"]=0
    with pytest.raises(DeploymentConfigError): DeploymentConfig.from_mapping(raw)
    raw=prod(); raw["unexpected"]=1
    with pytest.raises(DeploymentConfigError): DeploymentConfig.from_mapping(raw)

def test_audit_path_controlled():
    raw=prod(); raw["audit_log"]="/tmp/audit.log"
    with pytest.raises(DeploymentConfigError): DeploymentConfig.from_mapping(raw)

def test_environment_debug_flags_rejected():
    with pytest.raises(DeploymentConfigError): validate_environment({"AEGIS_DEBUG":"1"})
    validate_environment({"AEGIS_DEBUG":"0"})

def test_audit_log_hash_chain_and_tamper_detection(tmp_path):
    from aegis.auditlog import AuditLog
    p = tmp_path / "audit.jsonl"
    log = AuditLog(str(p))
    log.append("authorize", {"op_id": "x", "principal": "alice"})
    log.append("deny", {"reason": "replay"})
    assert log.verify()
    raw = p.read_text()
    p.write_text(raw.replace('"deny"', '"allow"', 1))
    assert not log.verify()

def test_audit_log_rejects_oversized_fields(tmp_path):
    from aegis.auditlog import AuditLog, AuditLogError
    log = AuditLog(str(tmp_path / "audit.jsonl"))
    with pytest.raises(AuditLogError):
        log.append("x", {"data": "a" * 5000})
