from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def test_dependency_lock_is_exact_and_minimal():
    text = (ROOT / "requirements-lock.txt").read_text().splitlines()
    assert text == ["cryptography==46.0.4", "pytest==9.0.2"]

def test_audit_has_bounded_timeout_and_hashing():
    text = (ROOT / "audit.py").read_text()
    assert "subprocess.run" in text
    assert "timeout=TIMEOUT" in text
    assert "sha256" in text
    assert re.search(r'AEGIS_AUDIT_TIMEOUT', text)

def test_release_tree_excludes_transient_python_artifacts():
    text = (ROOT / "audit.py").read_text()
    assert "__pycache__" in text
    assert ".pytest_cache" in text
    assert 'endswith((".pyc", ".pyo"))' in text
