# OSPS Baseline Assessment

Assessment target: Aegis review candidate
Baseline version: OpenSSF OSPS Baseline v2026.08.28
Assessment type: internal self-assessment; not third-party certification.

## Current posture

### Implemented or evidenced
- Security/threat documentation: `ATTACK_SURFACE.md`
- Build/dependency instructions: `README.md`, `requirements-lock.txt`
- Security traceability: `SECURITY_TRACEABILITY.md`
- Review/reproduction procedure: `REVIEW_PROCEDURE.md`, `REVIEWER_QUICKSTART.md`
- Release hashes/evidence: `EVIDENCE_INDEX.json`, `evidence-manifest.json`
- Security reporting process: `SECURITY.md`
- Contribution requirements: `CONTRIBUTING.md`
- Automated security/test workflow: `.github/workflows/security.yml`
- Ownership placeholder: `.github/CODEOWNERS`

### Still requires repository/deployment facts
- Authoritative remote repository and branch-protection settings
- MFA enforcement for maintainers
- Actual CODEOWNERS identities
- Signed release/attestation configuration
- Public discussion mechanism and project governance identities
- License selection and publication, if Aegis is intended to be open source

These cannot be honestly attested from a local artifact alone. The current OSPS Baseline says projects may self-attest, but the assessment is point-in-time and should identify the exact Baseline version used.
