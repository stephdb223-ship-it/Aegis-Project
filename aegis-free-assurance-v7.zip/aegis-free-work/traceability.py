"""Validate security-claim traceability for independent review."""
from __future__ import annotations
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DOC = ROOT / "SECURITY_TRACEABILITY.md"
ROW_RE = re.compile(r"^\|\s*(.*?)\s*\|\s*(.*?)\s*\|\s*(.*?)\s*\|\s*$")
PATH_RE = re.compile(r"`([^`]+)`")

def validate() -> dict:
    errors: list[str] = []
    if not DOC.is_file():
        return {"status": "FAIL", "claims": 0, "errors": ["missing SECURITY_TRACEABILITY.md"]}
    rows = []
    for line in DOC.read_text(encoding="utf-8").splitlines():
        m = ROW_RE.match(line)
        if m and m.group(1).lower() not in {"claim", "---"} and not set(m.group(1)) <= {"-"}:
            rows.append(m.groups())
    if not rows:
        errors.append("traceability table contains no claims")
    for i, (claim, code, evidence) in enumerate(rows, 1):
        if not claim:
            errors.append(f"row {i}: empty claim")
        code_paths = PATH_RE.findall(code)
        evidence_paths = PATH_RE.findall(evidence)
        if not code_paths:
            errors.append(f"row {i}: no code reference")
        if not evidence_paths and not any(token in evidence.lower() for token in ("audit", "stage", "gate", "campaign")):
            errors.append(f"row {i}: no evidence reference")
        for raw in code_paths + evidence_paths:
            raw = raw.rstrip(".,")
            p = ROOT / raw if not raw.startswith("tests/") else ROOT / raw
            if not p.exists():
                errors.append(f"row {i}: missing referenced path: {raw}")
    return {"status": "PASS" if not errors else "FAIL", "claims": len(rows), "errors": errors}

if __name__ == "__main__":
    result = validate()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)
