# Independent Reviewer Reproduction Procedure

1. Extract the release archive into a clean directory.
2. Use the pinned Python version and `requirements-lock.txt`.
3. Run `python -m pytest -q` from the repository root.
4. Run `python audit.py` and preserve stdout/stderr plus `audit-results.json`.
5. Independently inspect `REVIEW_PACKAGE.md`, `ATTACK_SURFACE.md`, and `SECURITY_TRACEABILITY.md` against source and tests.
6. Attempt to falsify each security objective with targeted negative tests.
7. Repeat the 5,000-step campaign using its documented seed(s) and compare deterministic traces.
8. Test persistence recovery at every exposed commit/failure boundary.
9. Validate PQC behavior against the exact provider/build available to the reviewer; do not infer FIPS 140 validation from algorithm support.
10. Report findings with severity, affected code, reproduction steps, expected behavior, observed behavior, and evidence.

## Acceptance rule
An independent review is complete only when the reviewer signs a separate report identifying scope, environment, methods, findings, residual risk, and disposition. Automated PASS results in this repository do not satisfy that external gate.
