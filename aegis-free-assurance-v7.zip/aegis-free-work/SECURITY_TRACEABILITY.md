# Security Claim → Evidence Traceability

| Claim | Code | Test/evidence |
|---|---|---|
| Authorization is policy/epoch constrained | `aegis/core.py` | `tests/test_core.py`, `tests/test_invariants.py` |
| Capabilities cannot be amplified | `aegis/core.py` | `tests/test_advanced.py`, `tests/test_hardening.py` |
| Replay protection survives persistence | `aegis/core.py`, `aegis/persistent.py` | `tests/test_persistence.py` |
| Quorum thresholds and signer membership are enforced | `aegis/quorum.py` | `tests/test_quorum_reconcile.py`, `tests/test_distributed.py` |
| Equivocation is detected/rejected | `aegis/distributed.py` | `tests/test_distributed.py`, `tests/test_campaign_5000.py` |
| Reconciliation respects ancestry/invariants | `aegis/reconcile.py`, `aegis/invariants.py` | `tests/test_stateful_campaign.py`, `tests/test_random_campaign.py` |
| Crypto migration cannot silently downgrade | `aegis/core.py`, `aegis/pqc.py` | `tests/test_pqc.py`, `tests/test_pqc_hardening.py` |
| PQC provider is context bound | `aegis/pqc_openssl.py` | `tests/test_openssl_pqc.py` |
| Release has no obvious secret material | `release_security.py` | audit release-security stage |
| Required release inputs are present and reproducible | `release_checks.py`, `requirements-lock.txt` | release-integrity/audit stages |
| Adversarial 5,000-step campaign remains invariant-safe | `tests/test_campaign_5000.py` | 5,000-step campaign gate |
