# Aegis Attack-Surface Inventory

| Surface | Threats | Primary implementation | Existing verification |
|---|---|---|---|
| Identity/epoch | stale identity, revoked epoch | `aegis/core.py`, `aegis/model.py` | `tests/test_core.py`, `tests/test_invariants.py` |
| Capabilities | escalation, invalid attenuation | `aegis/core.py` | `tests/test_advanced.py`, `tests/test_hardening.py` |
| Replay | duplicate single-use operation | `aegis/core.py`, `aegis/store.py` | `tests/test_core.py`, `tests/test_persistence.py` |
| Policy/crypto | downgrade, invalid migration | `aegis/core.py`, `aegis/pqc.py` | `tests/test_pqc.py`, `tests/test_pqc_hardening.py` |
| Quorum certificates | forged signer, bad threshold, wrong context | `aegis/quorum.py` | `tests/test_quorum_reconcile.py`, `tests/test_distributed.py` |
| Byzantine delivery | duplication, reordering, omission, equivocation | `aegis/distributed.py` | `tests/test_campaign_5000.py`, `tests/test_stateful_campaign.py` |
| Persistence | torn/failed transaction, stale writer | `aegis/persistent.py` | `tests/test_persistence.py` |
| Reconciliation | invalid ancestry, divergent histories | `aegis/reconcile.py` | `tests/test_quorum_reconcile.py`, `tests/test_stateful_campaign.py` |
| PQC provider | malformed outputs, wrong context, migration failure | `aegis/pqc_openssl.py` | `tests/test_openssl_pqc.py`, `tests/test_pqc_hardening.py` |
| Release artifacts | leaked secrets, untracked files, dependency drift | `release_security.py`, `release_checks.py` | `tests/test_release_assurance.py`, `tests/test_release_hardening.py` |
