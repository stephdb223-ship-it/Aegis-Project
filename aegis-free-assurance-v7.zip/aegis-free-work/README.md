# Aegis Reference Implementation

A compact executable reference model reconstructed from the Aegis architecture developed in this project.

Implemented here: identity/epoch handling, attenuating capabilities, policy and crypto-level migration, replay protection, atomic versioned state, quorum certificates, deterministic reconciliation, invariants, and executable tests.

This is **not** a production certification. PQC is represented as an explicit security-level migration policy; a concrete standardized PQC provider still requires separate validation.

Run:

```bash
python -m pytest -q
python audit.py
```

## Distributed verification layer

`aegis.distributed` provides a deterministic model for quorum delivery, duplicate/reordered messages, and signer equivocation. It is a verification harness, not a claim that Aegis is a production consensus implementation.

## Concrete standardized PQC integration

`aegis.pqc_openssl` provides a reference adapter for OpenSSL 3.5+ ML-DSA-65
(FIPS 204) and ML-KEM-768 (FIPS 203). The adapter uses the local OpenSSL
implementation and is intended for integration/verification, not a claim of
FIPS 140 validation or production certification. NIST identifies ML-DSA as a
standardized digital-signature scheme and ML-KEM as a standardized KEM.

The provider is deliberately separate from the core policy engine so a
validated cryptographic module can be substituted without changing Aegis
security semantics.

## 5,000-Step Adversarial Campaign

The release gate includes a deterministic 5,000-step distributed-state campaign. It
covers commits, duplicate delivery, reordering, signer equivocation, and dropped
messages, with safety invariants checked after every step. The campaign is seeded
and replayable; identical seeds must produce identical event traces.
