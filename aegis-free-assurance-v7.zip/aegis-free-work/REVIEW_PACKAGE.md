# Aegis Independent Security Review Package

## Scope
This package maps the executable reference implementation to its security claims and defines the work an independent reviewer should reproduce. It does **not** constitute an independent audit.

## Trust boundaries
1. **Caller → authorization core:** untrusted requests must be validated before state transition.
2. **Capability → authorization:** capabilities are attenuated; callers cannot gain authority through delegation.
3. **Replica/message → quorum/reconciliation:** messages and certificates are untrusted until membership, context, epoch, and signer rules validate them.
4. **Persistent store → recovery:** recovered state must preserve committed versions and security invariants.
5. **Crypto provider → protocol:** provider outputs are accepted only through explicit algorithm/version/context policy.

## Security objectives
- No authorization without valid identity, capability, epoch, and policy.
- No replay of single-use operations.
- No downgrade to a weaker disallowed crypto level.
- No authority escalation through capability attenuation/delegation.
- No acceptance of invalid or equivocating quorum evidence.
- Deterministic, ancestry-respecting reconciliation.
- Crash recovery preserves committed security state.
- Cryptographic context/domain separation prevents cross-protocol substitution.

## Out of scope for this reference release
Network transport security, OS/kernel security, HSM/FIPS-module validation, operational key custody, side-channel resistance, formal consensus proofs, and deployment-specific configuration are external review topics.
