"""Deterministic release-candidate assurance checks for Aegis."""
from __future__ import annotations
import hashlib, json, os, subprocess, sys, tempfile, zipfile, importlib.metadata
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCK = ROOT / "requirements-lock.txt"
REQUIRED = ["pyproject.toml", "requirements-lock.txt", "README.md", "audit.py", "release_checks.py"]
EXCLUDES = {".git", ".pytest_cache", "__pycache__"}
EXCLUDE_FILES = {"audit-results.json", "release-assurance.json", "evidence-manifest.json"}

def tree_digest() -> str:
    h = hashlib.sha256()
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or any(x in EXCLUDES or x.endswith(".egg-info") for x in p.relative_to(ROOT).parts):
            continue
        if p.suffix in {".pyc", ".pyo"} or p.name in EXCLUDE_FILES:
            continue
        rel = p.relative_to(ROOT).as_posix()
        h.update(rel.encode()); h.update(b"\0"); h.update(p.read_bytes()); h.update(b"\0")
    return h.hexdigest()

def check_lock() -> dict:
    text = LOCK.read_text().splitlines()
    pins = [x.strip() for x in text if x.strip() and not x.startswith("#")]
    return {"entries": pins, "all_pinned": all("==" in x for x in pins)}

def check_dependencies() -> dict:
    expected = {}
    for line in LOCK.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "==" in line:
            name, version = line.split("==", 1)
            expected[name.lower()] = version
    actual = {}
    for name in expected:
        try:
            actual[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual[name] = None
    return {"expected": expected, "actual": actual, "match": all(actual[k] == v for k, v in expected.items())}

def clean_rebuild() -> dict:
    with tempfile.TemporaryDirectory(prefix="aegis-clean-") as td:
        target = Path(td) / "src"
        subprocess.run(["cp", "-a", str(ROOT), str(target)], check=True)
        for p in target.rglob("__pycache__"):
            if p.is_dir(): subprocess.run(["rm", "-rf", str(p)], check=True)
        for p in target.rglob("*.pyc"):
            p.unlink(missing_ok=True)
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        r = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=target, env=env, capture_output=True, text=True, timeout=90)
        return {"returncode": r.returncode, "stdout_tail": r.stdout[-3000:], "stderr_tail": r.stderr[-1000:]}

def main() -> int:
    skip_clean = "--skip-clean" in sys.argv
    missing = [x for x in REQUIRED if not (ROOT / x).is_file()]
    lock = check_lock()
    dependencies = check_dependencies()
    clean = {"returncode": 0, "stdout_tail": "skipped (already executed by release gate)", "stderr_tail": ""} if skip_clean else clean_rebuild()
    result = {"required_files": {"missing": missing, "status": "PASS" if not missing else "FAIL"},
              "lock": lock,
              "dependencies": dependencies,
              "clean_rebuild": clean,
              "tree_sha256": tree_digest()}
    result["status"] = "PASS" if not missing and lock["all_pinned"] and dependencies["match"] and clean["returncode"] == 0 else "FAIL"
    (ROOT / "release-assurance.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__": raise SystemExit(main())
