# GitHub Repository Hardening Checklist

Use this checklist when creating the authoritative Aegis GitHub repository. These controls must be configured in GitHub; they cannot be proven by a ZIP artifact.

## Account and access
- [ ] Enable MFA for every maintainer with repository administration access.
- [ ] Use least-privilege repository roles for collaborators.
- [ ] Review installed GitHub Apps and OAuth applications.

## Primary branch
- [ ] Protect the primary branch.
- [ ] Require pull requests before merging.
- [ ] Require the security/test workflow to pass before merge.
- [ ] Prevent force-pushes and branch deletion.
- [ ] Require code-owner review once real CODEOWNERS identities are configured.

## Actions / CI
- [ ] Keep workflow `permissions` explicitly least-privilege.
- [ ] Keep third-party actions pinned to immutable commit SHAs.
- [ ] Do not expose secrets to pull-request code from untrusted forks.
- [ ] Review workflow changes as code-owner protected changes.

## Releases
- [ ] Use unique release identifiers (prefer SemVer or an equivalent immutable scheme).
- [ ] Publish release notes/change log.
- [ ] Publish SHA-256 hashes for every release asset.
- [ ] Configure signed releases or a signed release manifest/provenance mechanism.

## Security reporting
- [ ] Enable GitHub private vulnerability reporting or an equivalent private reporting channel.
- [ ] Publish and maintain `SECURITY.md` with response expectations.
- [ ] Enable repository security alerts/dependabot where applicable.

## Governance
- [ ] Configure a public discussion/issue mechanism appropriate to the project.
- [ ] Replace `.github/CODEOWNERS` placeholders with real accountable identities.
- [ ] Choose and publish an OSI/FSF-compatible license if Aegis will be released as open source.

## Scorecard
After the repository is public and configured, run the pinned Scorecard workflow and record the resulting SARIF/score in the review evidence. Do not self-assign an official Scorecard score.
