# Aegis Reviewer Quickstart

This package is intended to be independently reproduced from a clean checkout.

## Environment

- Python 3.10+
- Install exactly the versions in `requirements-lock.txt`.
- No network access is required by the core test suite after dependencies are installed.

## Reproduce the automated evidence

From the repository root, run:

```text
python -m pytest -q
python -m compileall -q aegis *.py
python review_handoff.py
python release_checks.py
python release_assurance.py
python release_security.py
```

The commands reproduce the regression, compilation, review-handoff, release-integrity,
dependency/rebuild-assurance, and security-hygiene gates.

## Evidence boundary

A PASS from these commands is **automated verification evidence only**. It is not an
independent security assessment, production deployment validation, or certification.
Those gates are intentionally recorded as `PENDING` in `evidence-manifest.json`.

## Review focus

Start with `ATTACK_SURFACE.md`, then `SECURITY_TRACEABILITY.md`, and use
`REVIEW_PROCEDURE.md` to reproduce the documented claims against source and tests.
