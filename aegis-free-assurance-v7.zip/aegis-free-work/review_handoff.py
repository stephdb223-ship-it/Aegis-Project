"""Validate that the Aegis release contains a coherent review-handoff package."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED_DOCS = (
    "README.md", "ATTACK_SURFACE.md", "REVIEW_PACKAGE.md",
    "REVIEW_PROCEDURE.md", "SECURITY_TRACEABILITY.md", "EVIDENCE_INDEX.json",
    "evidence-manifest.json", "requirements-lock.txt",
)
REQUIRED_MANIFEST_KEYS = ("release", "evidence_status", "required_gates", "external_gates")
REQUIRED_EXTERNAL_GATES = ("independent_security_review", "deployment_validation", "certification")


def validate() -> dict:
    missing = [p for p in REQUIRED_DOCS if not (ROOT / p).is_file()]
    errors: list[str] = []
    manifest = {}
    if not missing:
        try:
            manifest = json.loads((ROOT / "evidence-manifest.json").read_text())
        except Exception as exc:
            errors.append(f"invalid evidence-manifest.json: {exc}")
    for key in REQUIRED_MANIFEST_KEYS:
        if key not in manifest:
            errors.append(f"manifest missing key: {key}")
    external = manifest.get("external_gates", {})
    for gate in REQUIRED_EXTERNAL_GATES:
        if external.get(gate) != "PENDING":
            errors.append(f"external gate must remain PENDING: {gate}")
    if manifest.get("evidence_status") != "AUTOMATED_VERIFICATION_ONLY":
        errors.append("evidence status must distinguish automated evidence from external review")
    return {"status": "PASS" if not missing and not errors else "FAIL", "missing": missing, "errors": errors}


if __name__ == "__main__":
    result = validate()
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)
