#!/usr/bin/env bash
set -euo pipefail

ZIP="${1:-aegis-free-assurance-v7.zip}"
if [[ ! -f "$ZIP" ]]; then
  echo "Missing $ZIP" >&2
  exit 1
fi
rm -rf /tmp/aegis-import
mkdir -p /tmp/aegis-import
unzip -q "$ZIP" -d /tmp/aegis-import
cp -a /tmp/aegis-import/aegis-free-work/. .
rm -f aegis-free-assurance-v7.zip aegis-free-assurance-v6.zip aegis-free-assurance-v5.zip
rm -rf .pytest_cache __pycache__ aegis/__pycache__ tests/__pycache__
python -m compileall -q aegis tests
python -m pytest -q
git status --short
echo "Import and verification complete. Review git status, then commit and push when ready."
