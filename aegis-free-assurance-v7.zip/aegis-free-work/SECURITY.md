# Security Policy

## Supported versions

Security fixes are prioritized for the current release candidate and the immediately preceding supported release when practical.

## Reporting a vulnerability

Do not disclose suspected vulnerabilities publicly before coordinated remediation. For a real deployment, configure a private security contact (for example, a repository security-advisory channel or dedicated security email) before publication.

Include the affected component, reproduction steps, impact, and any relevant logs or traces. Do not include live secrets or private keys.

## Scope

The security review should cover authorization, capability attenuation, persistence, distributed/quorum behavior, cryptography/PQC adapters, audit integrity, protocol parsing, key lifecycle, upgrade/rollback, and deployment boundaries.
