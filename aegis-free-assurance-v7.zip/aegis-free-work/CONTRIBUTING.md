# Contributing

Aegis changes must preserve the security invariants documented in `ATTACK_SURFACE.md` and `SECURITY_TRACEABILITY.md`.

## Required checks

Before proposing a change:

1. Run the test suite.
2. Run compilation checks.
3. Run release-integrity and security-hygiene checks.
4. Add regression coverage for security-relevant behavior.
5. Do not commit secrets, private keys, credentials, generated caches, or local environment files.

Security-sensitive changes require explicit review of affected threat-model entries and evidence mappings.
