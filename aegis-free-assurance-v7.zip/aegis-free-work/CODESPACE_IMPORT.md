# Importing this baseline into the GitHub repository

This package is the current Aegis free-assurance baseline (v7). If the ZIP is uploaded to the repository, run the following from the repository root in the Codespace terminal.

```bash
set -e
rm -rf /tmp/aegis-import
mkdir -p /tmp/aegis-import
unzip -q aegis-free-assurance-v7.zip -d /tmp/aegis-import
cp -a /tmp/aegis-import/aegis-free-work/. .
rm -f aegis-free-assurance-v7.zip aegis-free-assurance-v6.zip
rm -rf .pytest_cache __pycache__ aegis/__pycache__ tests/__pycache__
python -m compileall -q aegis tests
python -m pytest -q
git status --short
git add .
git commit -m "Import Aegis security assurance baseline"
git push origin main
```

Do not commit generated caches or transient runtime databases.

After the push, verify the GitHub Actions **Security checks** workflow and its OpenSSF Scorecard job.
