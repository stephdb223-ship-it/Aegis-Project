"""Static release-security hygiene checks for the Aegis reference build."""
from __future__ import annotations
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TEXT_SUFFIXES = {".py", ".md", ".toml", ".txt", ".json", ".yaml", ".yml"}
SECRET_PATTERNS = (
    re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{20,}"),
)


def scan() -> list[str]:
    findings: list[str] = []
    for p in ROOT.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEXT_SUFFIXES:
            continue
        if any(part in {".git", ".pytest_cache", "__pycache__"} for part in p.relative_to(ROOT).parts):
            continue
        text = p.read_text(errors="ignore")
        for pattern in SECRET_PATTERNS:
            if pattern.search(text):
                findings.append(str(p.relative_to(ROOT)))
                break
    return sorted(set(findings))


def main() -> int:
    findings = scan()
    if findings:
        print("potential secret material found:")
        print("\n".join(findings))
        return 1
    print("release security hygiene: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
