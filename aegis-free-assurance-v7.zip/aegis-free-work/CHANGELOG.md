# Changelog

## 0.2.0-review

Security-assurance baseline for independent review, including protocol hardening,
distributed-failure testing, crash recovery, key lifecycle controls, audit-chain
integrity, deployment validation, deterministic endurance campaigns, and review
traceability.

This release candidate is **not** a certification and has not received an
independent third-party security audit.


## 0.2.1-review

- Mark OpenSSL ML-DSA and ML-KEM adapters as non-production-ready until
  deployment validation and applicable cryptographic module validation exist.
- Isolate each OpenSSL PQC operation in its own temporary workspace to avoid
  concurrent file collisions when provider instances are shared across threads.
- Add concurrent ML-DSA signing/verification and ML-KEM encapsulation/
  decapsulation coverage.
- Make the audit test runner independent of globally auto-loaded pytest plugins.

This remains a reference/integration release candidate, not a certification
or an independently audited production release.


## 0.2.2-review

- Corrected cross-module campaign safety checks to validate incremental state
  on each step and perform a complete historical verification at campaign end,
  avoiding quadratic repeated serialization of the entire commit history.
- Added a concurrency regression test for shared OpenSSL ML-DSA and ML-KEM
  provider instances.
- Explicitly mark OpenSSL PQC adapters as not production-ready pending
  deployment validation and applicable cryptographic module validation.
- Updated the Codespace import instructions and script for assurance package v7.

This is still a reference implementation and review candidate, not an
independently audited or certified production release.
