"""Deterministic release-integrity checks for the Aegis reference build."""
from __future__ import annotations
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIRED = (
    "aegis/core.py", "aegis/crypto.py", "aegis/distributed.py",
    "aegis/invariants.py", "aegis/model.py", "aegis/persistent.py",
    "aegis/pqc.py", "aegis/quorum.py", "aegis/reconcile.py",
    "aegis/store.py", "requirements-lock.txt", "release_security.py",
)

def source_digest() -> str:
    h = hashlib.sha256()
    for name in REQUIRED:
        p = ROOT / name
        if not p.is_file():
            raise RuntimeError(f"missing required release file: {name}")
        h.update(name.encode())
        h.update(b"\0")
        h.update(p.read_bytes())
        h.update(b"\0")
    return h.hexdigest()

def main() -> int:
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10+ required")
    digest = source_digest()
    print(f"release source digest: {digest}")
    print("release integrity checks: PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
