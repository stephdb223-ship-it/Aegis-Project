import hashlib, json, re
from pathlib import Path

ROOT=Path(__file__).resolve().parent
LOCK=ROOT/"requirements-lock.txt"
OUT=ROOT/"sbom.spdx.json"

pkgs=[]
for line in LOCK.read_text().splitlines():
    line=line.strip()
    if not line or line.startswith("#") or "==" not in line:
        continue
    name, version = line.split("==",1)
    name=name.strip(); version=version.strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", name) or not re.fullmatch(r"[A-Za-z0-9_.!+-]+", version):
        raise SystemExit(f"invalid locked dependency: {line}")
    pkgs.append((name,version))

packages=[]
relationships=[]
for name,version in pkgs:
    spdxid="SPDXRef-Package-"+re.sub(r"[^A-Za-z0-9.-]","-",name)
    purl="pkg:pypi/"+name.lower()+"@"+version
    packages.append({
        "SPDXID":spdxid,
        "name":name,
        "versionInfo":version,
        "downloadLocation":"NOASSERTION",
        "filesAnalyzed":False,
        "licenseConcluded":"NOASSERTION",
        "licenseDeclared":"NOASSERTION",
        "supplier":"NOASSERTION",
        "externalRefs":[{"referenceCategory":"PACKAGE-MANAGER","referenceType":"purl","referenceLocator":purl}],
    })
    relationships.append({"spdxElementId":"SPDXRef-DOCUMENT","relationshipType":"DEPENDS_ON","relatedSpdxElement":spdxid})

digest=hashlib.sha256(LOCK.read_bytes()).hexdigest()
doc={
 "spdxVersion":"SPDX-2.3",
 "dataLicense":"CC0-1.0",
 "SPDXID":"SPDXRef-DOCUMENT",
 "name":"Aegis SBOM",
 "documentNamespace":"https://aegis.invalid/spdx/aegis-locked-dependencies",
 "creationInfo":{"created":"2026-09-08T00:00:00Z","creators":["Tool: Aegis SBOM generator"],"comment":"Generated from requirements-lock.txt; lockfile SHA-256: "+digest},
 "packages":packages,
 "relationships":relationships,
}
OUT.write_text(json.dumps(doc,indent=2,sort_keys=True)+"\n")
print(OUT)
