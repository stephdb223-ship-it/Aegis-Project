from __future__ import annotations
from dataclasses import dataclass
from threading import RLock
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

class KeyManagerError(Exception):
    pass

@dataclass(frozen=True)
class KeyHandle:
    key_id: str
    version: int
    algorithm: str = "Ed25519"

class KeyManager:
    """Minimal external-KMS/HSM boundary.

    Private keys remain inside the provider. Aegis receives only an opaque
    handle and the public verification key. Production deployments can
    replace this implementation with an HSM/KMS adapter without changing
    authorization state semantics.
    """
    def generate(self, key_id: str) -> tuple[KeyHandle, bytes]:
        raise NotImplementedError
    def sign(self, handle: KeyHandle, payload: bytes) -> bytes:
        raise NotImplementedError
    def verify_key(self, handle: KeyHandle) -> bytes:
        raise NotImplementedError
    def rotate(self, key_id: str) -> tuple[KeyHandle, bytes]:
        raise NotImplementedError
    def destroy(self, key_id: str) -> None:
        raise NotImplementedError

class InMemoryKeyManager(KeyManager):
    """Test/reference provider; intentionally not an HSM or KMS."""
    def __init__(self):
        self._lock=RLock(); self._keys: dict[str, list[Ed25519PrivateKey]]={}; self._active: dict[str,int]={}
    def _handle(self, key_id: str, version: int) -> KeyHandle:
        return KeyHandle(key_id, version)
    def generate(self, key_id: str):
        with self._lock:
            if not key_id or key_id in self._keys: raise KeyManagerError("duplicate key id")
            k=Ed25519PrivateKey.generate(); self._keys[key_id]=[k]; self._active[key_id]=1
            return self._handle(key_id,1), k.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    def sign(self, handle: KeyHandle, payload: bytes) -> bytes:
        with self._lock:
            versions=self._keys.get(handle.key_id)
            if not versions or not 1 <= handle.version <= len(versions): raise KeyManagerError("invalid key handle")
            return versions[handle.version-1].sign(payload)
    def verify_key(self, handle: KeyHandle) -> bytes:
        with self._lock:
            versions=self._keys.get(handle.key_id)
            if not versions or not 1 <= handle.version <= len(versions): raise KeyManagerError("invalid key handle")
            return versions[handle.version-1].public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    def rotate(self, key_id: str):
        with self._lock:
            if key_id not in self._keys: raise KeyManagerError("unknown key id")
            k=Ed25519PrivateKey.generate(); self._keys[key_id].append(k); v=len(self._keys[key_id]); self._active[key_id]=v
            return self._handle(key_id,v), k.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    def destroy(self, key_id: str):
        with self._lock:
            if key_id not in self._keys: raise KeyManagerError("unknown key id")
            del self._keys[key_id]; self._active.pop(key_id,None)
    def active_version(self, key_id: str) -> int:
        with self._lock:
            if key_id not in self._active: raise KeyManagerError("unknown key id")
            return self._active[key_id]
