from __future__ import annotations
import base64, json, os, sqlite3
from threading import RLock
from dataclasses import asdict
from pathlib import Path
from .model import SecurityState, Policy, Identity, Capability
from .store import Conflict

SCHEMA = """
CREATE TABLE IF NOT EXISTS aegis_state (
  id INTEGER PRIMARY KEY CHECK(id=1),
  version INTEGER NOT NULL,
  payload BLOB NOT NULL
);
"""

def _encode(s: SecurityState) -> bytes:
    d = {
        "version": s.version, "epoch": s.epoch,
        "policy": {"version": s.policy.version, "min_crypto": s.policy.min_crypto,
                   "allowed_actions": sorted(s.policy.allowed_actions)},
        "crypto_level": s.crypto_level,
        "identities": [{"id": i.id, "key": base64.b64encode(i.key).decode(), "epoch": i.epoch,
                        "revoked": i.revoked, "parent": i.parent} for i in s.identities],
        "capabilities": [{"id": c.id, "issuer": c.issuer, "parent": c.parent, "resource": c.resource,
                          "actions": sorted(c.actions), "max_depth": c.max_depth, "epoch": c.epoch,
                          "revoked": c.revoked} for c in s.capabilities],
        "consumed_ops": sorted(s.consumed_ops), "branch": s.branch,
        "quarantined": list(s.quarantined),
    }
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()

def _decode(raw: bytes) -> SecurityState:
    d=json.loads(raw)
    p=d["policy"]
    return SecurityState(
        version=int(d["version"]), epoch=int(d["epoch"]),
        policy=Policy(int(p["version"]), p["min_crypto"], frozenset(p["allowed_actions"])),
        crypto_level=d["crypto_level"],
        identities=tuple(Identity(x["id"], base64.b64decode(x["key"]), int(x["epoch"]), bool(x["revoked"]), x.get("parent")) for x in d["identities"]),
        capabilities=tuple(Capability(x["id"], x["issuer"], x.get("parent"), x["resource"], frozenset(x["actions"]), int(x["max_depth"]), int(x["epoch"]), bool(x["revoked"])) for x in d["capabilities"]),
        consumed_ops=frozenset(d["consumed_ops"]), branch=d["branch"], quarantined=tuple(d["quarantined"]),
    )

class DurableStore:
    """SQLite-backed atomic state store with durable transactions and version CAS."""
    def __init__(self, path: str | os.PathLike, initial: SecurityState | None = None):
        self.path=str(Path(path))
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._db=sqlite3.connect(self.path, isolation_level=None, check_same_thread=False)
        self._lock=RLock()
        self._db.execute("PRAGMA busy_timeout=5000")
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.execute("PRAGMA synchronous=FULL")
        self._db.executescript(SCHEMA)
        row=self._db.execute("SELECT version,payload FROM aegis_state WHERE id=1").fetchone()
        if row is None:
            state=initial or SecurityState()
            self._db.execute("BEGIN IMMEDIATE")
            try:
                self._db.execute("INSERT INTO aegis_state(id,version,payload) VALUES(1,?,?)", (state.version,_encode(state)))
                self._db.execute("COMMIT")
            except Exception:
                self._db.execute("ROLLBACK"); raise
    def read(self):
        with self._lock:
            return self._read_locked()

    def _read_locked(self):
        row=self._db.execute("SELECT version,payload FROM aegis_state WHERE id=1").fetchone()
        if row is None: raise RuntimeError("missing durable state")
        state=_decode(row[1])
        if state.version != row[0]: raise RuntimeError("durable state version mismatch")
        return state
    def commit(self, expected_version:int, new_state:SecurityState):
        with self._lock:
            return self._commit_locked(expected_version, new_state)

    def _commit_locked(self, expected_version:int, new_state:SecurityState):
        if new_state.version != expected_version+1: raise Conflict("non-monotonic commit")
        self._db.execute("BEGIN IMMEDIATE")
        try:
            cur=self._db.execute("UPDATE aegis_state SET version=?,payload=? WHERE id=1 AND version=?",
                                 (new_state.version,_encode(new_state),expected_version))
            if cur.rowcount != 1:
                self._db.execute("ROLLBACK"); raise Conflict("stale version")
            self._db.execute("COMMIT")
            return new_state
        except Exception:
            try: self._db.execute("ROLLBACK")
            except Exception: pass
            raise
    def close(self):
        with self._lock:
            self._db.close()
