from __future__ import annotations
from dataclasses import dataclass, field
from typing import FrozenSet, Optional, Tuple

@dataclass(frozen=True)
class Identity:
    id: str
    key: bytes
    epoch: int
    revoked: bool=False
    parent: Optional[str]=None

@dataclass(frozen=True)
class Capability:
    id: str
    issuer: str
    parent: Optional[str]
    resource: str
    actions: FrozenSet[str]
    max_depth: int
    epoch: int
    revoked: bool=False

@dataclass(frozen=True)
class Policy:
    version: int
    min_crypto: str = "classical"
    allowed_actions: FrozenSet[str] = frozenset()

@dataclass(frozen=True)
class Operation:
    op_id: str
    principal: str
    capability: str
    resource: str
    action: str
    epoch: int
    crypto_level: str

@dataclass(frozen=True)
class Evidence:
    op_id: str
    state_version: int
    epoch: int
    policy_version: int
    branch: str
    digest: str

@dataclass(frozen=True)
class SecurityState:
    version: int=0
    epoch: int=0
    policy: Policy=field(default_factory=lambda: Policy(0))
    crypto_level: str="classical"
    identities: Tuple[Identity,...]=()
    capabilities: Tuple[Capability,...]=()
    consumed_ops: FrozenSet[str]=frozenset()
    branch: str="root"
    quarantined: Tuple[str,...]=()
