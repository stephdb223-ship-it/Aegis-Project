from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Iterable

class InjectedFault(RuntimeError):
    """Deterministic test-only interruption at a named boundary."""

@dataclass
class FaultPlan:
    points: frozenset[str]
    def __init__(self, points: Iterable[str] = ()):
        object.__setattr__(self, 'points', frozenset(points))
    def hit(self, point: str) -> None:
        if point in self.points:
            raise InjectedFault(point)

class FaultInjector:
    """Test harness for exercising fail-stop boundaries without corrupting APIs."""
    def __init__(self, plan: FaultPlan | None = None):
        self.plan = plan or FaultPlan()
        self.hits: list[str] = []
    def hit(self, point: str) -> None:
        self.hits.append(point)
        self.plan.hit(point)
