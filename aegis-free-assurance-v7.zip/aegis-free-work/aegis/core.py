from __future__ import annotations
from dataclasses import replace
from threading import RLock
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from .model import *
from .store import AtomicStore, Conflict
from .persistent import DurableStore
from .crypto import LEVELS,digest
from .invariants import check_state
from .keymanager import KeyManager

class AegisError(Exception): pass
class AuthorizationDenied(AegisError): pass

class Aegis:
    def __init__(self, store=None, key_manager: KeyManager|None=None):
        self.store=store or AtomicStore(); self._lock=RLock(); self.key_manager=key_manager
        self._keys={}; self._quorum=None
    def register_identity(self, ident:str, key:bytes|None=None):
        with self._lock:
            s=self.store.read();
            if any(i.id==ident for i in s.identities): raise AegisError("duplicate identity")
            if self.key_manager is not None and key is None:
                handle, public_key = self.key_manager.generate(ident)
                # Identity.key is the public verification key when an external
                # key manager is configured; private material never enters state.
                k = public_key
            else:
                k=key or Ed25519PrivateKey.generate().private_bytes_raw()
            ns=replace(s,version=s.version+1,identities=s.identities+(Identity(ident,k,s.epoch),))
            check_state(ns); self.store.commit(s.version,ns); return k
    def revoke_identity(self, ident:str):
        with self._lock:
            s=self.store.read(); ids=tuple(replace(i,revoked=True) if i.id==ident else i for i in s.identities)
            if ids==s.identities: raise AegisError("unknown identity")
            ns=replace(s,version=s.version+1,epoch=s.epoch+1,identities=ids)
            check_state(ns); self.store.commit(s.version,ns)
    def issue_capability(self,cid,issuer,resource,actions,max_depth=3,parent=None):
        with self._lock:
            s=self.store.read(); ids={i.id:i for i in s.identities}; caps={c.id:c for c in s.capabilities}
            if issuer not in ids or ids[issuer].revoked: raise AegisError("invalid issuer")
            if parent:
                p=caps.get(parent)
                if not p or p.revoked or p.epoch<s.epoch: raise AegisError("invalid parent")
                if resource!=p.resource or not set(actions)<=p.actions or max_depth>=p.max_depth: raise AegisError("non-attenuating delegation")
            c=Capability(cid,issuer,parent,resource,frozenset(actions),max_depth,s.epoch)
            if cid in caps: raise AegisError("duplicate capability")
            ns=replace(s,version=s.version+1,capabilities=s.capabilities+(c,)); check_state(ns); self.store.commit(s.version,ns); return c
    def set_policy(self, allowed_actions, min_crypto=None):
        with self._lock:
            s=self.store.read(); mc=min_crypto or s.crypto_level
            if mc not in LEVELS: raise AegisError("unknown crypto level")
            if LEVELS[mc]<LEVELS[s.crypto_level]: raise AegisError("crypto downgrade")
            p=Policy(s.policy.version+1,mc,frozenset(allowed_actions))
            ns=replace(s,version=s.version+1,policy=p,crypto_level=max((s.crypto_level, mc), key=lambda x: LEVELS[x])); check_state(ns); self.store.commit(s.version,ns)
    def migrate_crypto(self,target):
        with self._lock:
            s=self.store.read()
            if target not in LEVELS or LEVELS[target]<LEVELS[s.crypto_level]: raise AegisError("downgrade")
            if target==s.crypto_level: return
            ns=replace(s,version=s.version+1,epoch=s.epoch+1,crypto_level=target,policy=replace(s.policy,version=s.policy.version+1,min_crypto=target))
            check_state(ns); self.store.commit(s.version,ns)
    def authorize(self,op:Operation)->Evidence:
        with self._lock:
            s=self.store.read(); ids={i.id:i for i in s.identities}; caps={c.id:c for c in s.capabilities}
            if op.op_id in s.consumed_ops: raise AuthorizationDenied("replay")
            i=ids.get(op.principal); c=caps.get(op.capability)
            if not i or i.revoked or i.epoch>s.epoch: raise AuthorizationDenied("identity")
            if not c or c.revoked or c.epoch!=s.epoch: raise AuthorizationDenied("capability epoch")
            if c.issuer!=i.id or c.resource!=op.resource or op.action not in c.actions: raise AuthorizationDenied("capability")
            if op.epoch!=s.epoch or LEVELS[op.crypto_level]<LEVELS[s.policy.min_crypto]: raise AuthorizationDenied("freshness/crypto")
            if op.action not in s.policy.allowed_actions: raise AuthorizationDenied("policy")
            ns=replace(s,version=s.version+1,consumed_ops=frozenset(set(s.consumed_ops)|{op.op_id})); check_state(ns); self.store.commit(s.version,ns)
            ev=Evidence(op.op_id,ns.version,ns.epoch,ns.policy.version,ns.branch,digest(op.op_id,op.principal,op.capability,op.resource,op.action,str(op.epoch),op.crypto_level,str(ns.version)))
            return ev
