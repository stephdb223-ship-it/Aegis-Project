from __future__ import annotations

import base64
import json
from dataclasses import asdict
from typing import Any

from .crypto import digest
from .distributed import Commit, Statement
from .quorum import Certificate

# Conservative wire limits. These are protocol limits, not Python/runtime limits.
MAX_MESSAGE_BYTES = 64 * 1024
MAX_STRING = 512
MAX_SIGNERS = 256
MAX_MEMBERSHIP = 256
MAX_DEPTH = 1_000_000
PROTOCOL_VERSION = 1
SUPPORTED_PROTOCOL_VERSIONS = frozenset({PROTOCOL_VERSION})


def _s(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value or len(value) > MAX_STRING:
        raise ValueError(f"invalid {name}")
    return value


def _i(value: Any, name: str, minimum: int = 0) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum or value > MAX_DEPTH:
        raise ValueError(f"invalid {name}")
    return value


def _canonical(obj: dict[str, Any]) -> bytes:
    # Explicit sorted keys and compact separators remove serializer ambiguity.
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def encode_statement(statement: Statement) -> bytes:
    obj = {"type": "statement", "version": PROTOCOL_VERSION, "signer": _s(statement.signer, "signer"),
           "state_version": _i(statement.state_version, "state_version", 0),
           "epoch": _i(statement.epoch, "epoch", 0),
           "transition_digest": _s(statement.transition_digest, "transition_digest")}
    return _bounded(_canonical(obj))


def encode_commit(commit: Commit) -> bytes:
    c = commit.certificate
    signers = sorted(c.signers)
    if len(signers) > MAX_SIGNERS:
        raise ValueError("too many signers")
    obj = {"type": "commit", "version": PROTOCOL_VERSION, "certificate": {
        "state_version": _i(c.state_version, "state_version", 1),
        "epoch": _i(c.epoch, "epoch", 0),
        "transition_digest": _s(c.transition_digest, "transition_digest"),
        "signers": [_s(x, "signer") for x in signers],
        "membership_digest": _s(c.membership_digest, "membership_digest")},
        "state_digest": _s(commit.state_digest, "state_digest")}
    return _bounded(_canonical(obj))


def decode_statement(data: bytes | bytearray | memoryview) -> Statement:
    obj = _load(data, "statement")
    if set(obj) != {"type", "version", "signer", "state_version", "epoch", "transition_digest"} or obj["type"] != "statement":
        raise ValueError("invalid statement envelope")
    _version(obj["version"])
    return Statement(_s(obj["signer"], "signer"), _i(obj["state_version"], "state_version"),
                     _i(obj["epoch"], "epoch"), _s(obj["transition_digest"], "transition_digest"))


def decode_commit(data: bytes | bytearray | memoryview) -> Commit:
    obj = _load(data, "commit")
    if set(obj) != {"type", "version", "certificate", "state_digest"} or obj["type"] != "commit":
        raise ValueError("invalid commit envelope")
    _version(obj["version"])
    c = obj["certificate"]
    if not isinstance(c, dict) or set(c) != {"state_version", "epoch", "transition_digest", "signers", "membership_digest"}:
        raise ValueError("invalid certificate envelope")
    signers = c["signers"]
    if not isinstance(signers, list) or len(signers) > MAX_SIGNERS or len(set(signers)) != len(signers):
        raise ValueError("invalid signer set")
    if signers != sorted(signers):
        raise ValueError("non-canonical signer order")
    cert = Certificate(_i(c["state_version"], "state_version", 1), _i(c["epoch"], "epoch"),
                       _s(c["transition_digest"], "transition_digest"),
                       frozenset(_s(x, "signer") for x in signers), _s(c["membership_digest"], "membership_digest"))
    return Commit(cert, _s(obj["state_digest"], "state_digest"))


def message_id(data: bytes) -> str:
    # Hash the exact wire representation so replay tracking is serialization-bound.
    if len(data) > MAX_MESSAGE_BYTES:
        raise ValueError("message too large")
    return digest(data)


def _version(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value not in SUPPORTED_PROTOCOL_VERSIONS:
        raise ValueError("unsupported protocol version")
    return value


def _bounded(data: bytes) -> bytes:
    if len(data) > MAX_MESSAGE_BYTES:
        raise ValueError("message too large")
    return data


def _load(data: bytes | bytearray | memoryview, expected: str) -> dict[str, Any]:
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise ValueError("message must be bytes")
    raw = bytes(data)
    _bounded(raw)
    try:
        obj = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError("invalid JSON message") from exc
    if not isinstance(obj, dict):
        raise ValueError(f"invalid {expected} message")
    # Reject duplicate-key ambiguity by reserializing and requiring exact canonical form.
    if _canonical(obj) != raw:
        raise ValueError("non-canonical message")
    return obj
