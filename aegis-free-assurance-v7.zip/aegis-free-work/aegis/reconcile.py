from __future__ import annotations
from dataclasses import dataclass
from .crypto import digest

@dataclass(frozen=True)
class Branch:
    branch_id:str
    parent:str
    state_version:int
    epoch:int
    transition_digest:str
    authoritative:bool=True

def validate_branches(branches:list[Branch], current_epoch:int):
    if current_epoch < 0:
        raise ValueError("invalid epoch")
    seen=set()
    for b in branches:
        if not b.branch_id or b.branch_id in seen:
            raise ValueError("duplicate/empty branch id")
        seen.add(b.branch_id)
        if b.state_version < 1 or b.epoch < 0 or not b.transition_digest:
            raise ValueError("invalid branch")
        if b.epoch == current_epoch and not b.parent:
            raise ValueError("authoritative branch missing parent")

def choose(branches:list[Branch], current_epoch:int):
    validate_branches(branches,current_epoch)
    valid=[b for b in branches if b.authoritative and b.epoch==current_epoch]
    if not valid: raise ValueError("no valid branch")
    winner=min(valid,key=lambda b:(-b.state_version,b.branch_id))
    losers=tuple(sorted(b.branch_id for b in valid if b.branch_id!=winner.branch_id))
    return winner, losers

def branch_digest(b:Branch)->str:
    return digest(b.branch_id,b.parent,str(b.state_version),str(b.epoch),b.transition_digest,str(b.authoritative))
