"""PQC provider boundary.

The reference build intentionally does not ship a PQC primitive. This module
provides a strict provider interface and a test provider so migration logic can
be exercised without falsely claiming production PQC security.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib, hmac

class PQCProviderError(Exception):
    pass

class PQCProvider:
    name = "abstract"
    algorithm = "unspecified"
    security_level = 2
    production = False

    def sign(self, message: bytes) -> bytes:
        raise NotImplementedError
    def verify(self, message: bytes, signature: bytes) -> bool:
        raise NotImplementedError

@dataclass(frozen=True)
class TestPQCProvider(PQCProvider):
    __test__ = False
    """Non-production provider for migration/integration tests only."""
    secret: bytes = b"AEGIS-TEST-PQC"
    name: str = "test-pqc"
    algorithm: str = "TEST-ONLY-HASH-SIGN"
    security_level: int = 2
    production: bool = False

    def sign(self, message: bytes) -> bytes:
        return hmac.new(self.secret, b"AEGIS-PQC-SIG\x00" + message, hashlib.sha256).digest()

    def verify(self, message: bytes, signature: bytes) -> bool:
        return hmac.compare_digest(self.sign(message), signature)

class PQCRegistry:
    def __init__(self):
        self._providers: dict[str, PQCProvider] = {}

    def register(self, provider: PQCProvider) -> None:
        if provider.name in self._providers:
            raise PQCProviderError("duplicate provider")
        if provider.security_level < 2:
            raise PQCProviderError("provider is below PQC security level")
        self._providers[provider.name] = provider

    def require(self, name: str) -> PQCProvider:
        try:
            return self._providers[name]
        except KeyError:
            raise PQCProviderError(f"PQC provider unavailable: {name}")

    def production_ready(self, name: str) -> bool:
        return self.require(name).production
