from __future__ import annotations
from dataclasses import dataclass, replace
import random
from .distributed import DistributedSimulator, Commit
from .quorum import make_certificate
from .crypto import digest

@dataclass(frozen=True)
class Event:
    kind: str
    version: int
    epoch: int
    branch: str
    digest: str

class StatefulCampaign:
    """Deterministic stateful distributed safety campaign.

    This is a model-level adversarial harness. It deliberately does not claim
    to implement production consensus or Byzantine networking.
    """
    def __init__(self, seed: int, members: tuple[str, ...] = ("n1","n2","n3","n4","n5")):
        self.rng = random.Random(seed)
        self.sim = DistributedSimulator(set(members), 3)
        self.history: list[Event] = []
        self.version = 0
        self.epoch = 0
        self.branch = "root"
        self.last_digest = digest("root")
        self.equivocation_version: dict[str, int] = {}

    def step(self) -> Event:
        action = self.rng.choice(("commit","duplicate","reorder","equivocate","drop"))
        if action == "commit" or not self.history:
            candidate_version = self.version + 1
            td = digest(self.last_digest, str(candidate_version), str(self.epoch), str(self.rng.randrange(1<<30)))
            signers = set(self.rng.sample(sorted(self.sim.quorum.members), 3))
            try:
                cert = self.sim.certificate(candidate_version, self.epoch, td, signers)
            except ValueError:
                # A certificate containing an already-equivocating signer is
                # rejected rather than mutating authoritative state.
                ev = Event("rejected_commit", self.version, self.epoch, self.branch, td)
            else:
                self.version = candidate_version
                commit = Commit(cert, digest(td, self.branch))
                self.sim.broadcast(commit, set(self.rng.sample(sorted(self.sim.replicas), self.rng.randint(1,5))))
                self.last_digest = td
                ev = Event("commit", self.version, self.epoch, self.branch, td)
        elif action == "duplicate":
            rid = self.rng.choice(sorted(self.sim.replicas))
            replica = self.sim.replicas[rid]
            if replica.committed:
                self.sim.broadcast(replica.committed[-1], {rid})
            ev = Event("duplicate", self.version, self.epoch, self.branch, self.last_digest)
        elif action == "reorder":
            rid = self.rng.choice(sorted(self.sim.replicas))
            replica = self.sim.replicas[rid]
            if len(replica.committed) >= 2:
                old = replica.committed[-2]
                self.sim.broadcast(old, {rid})
            ev = Event("reorder", self.version, self.epoch, self.branch, self.last_digest)
        elif action == "equivocate":
            signer = self.rng.choice(sorted(self.sim.quorum.members))
            base = digest(self.last_digest, str(self.version), str(self.epoch))
            self.sim.statement(signer, self.version, self.epoch, base + "a")
            self.sim.statement(signer, self.version, self.epoch, base + "b")
            self.equivocation_version[signer] = self.version
            ev = Event("equivocate", self.version, self.epoch, self.branch, base)
        else:
            ev = Event("drop", self.version, self.epoch, self.branch, self.last_digest)
        self.history.append(ev)
        self.assert_safety()
        return ev

    def assert_safety(self):
        # No replica may accept a lower version after a higher committed version.
        for replica in self.sim.replicas.values():
            versions = [c.certificate.state_version for c in replica.committed]
            assert versions == sorted(versions), (replica.replica_id, versions)
        # Once equivocation is observed at a version, that signer cannot
        # certify a later version. Earlier valid certificates remain valid.
        for signer, first_bad_version in self.equivocation_version.items():
            for replica in self.sim.replicas.values():
                for commit in replica.committed:
                    if commit.certificate.state_version > first_bad_version:
                        assert signer not in commit.certificate.signers

    def run(self, steps: int = 250):
        for _ in range(steps):
            self.step()
        return len(self.history)
