from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

from .auditlog import AuditLog, AuditLogError
from .deployment import DeploymentConfig, DeploymentConfigError
from .invariants import check_state
from .persistent import DurableStore

class RecoveryError(RuntimeError):
    pass

@dataclass(frozen=True)
class RecoveryReport:
    state_version: int
    audit_valid: bool
    state_valid: bool
    database_valid: bool

class StartupRecoveryGate:
    """Fail-closed startup gate for durable state, audit history, and deployment config."""
    def __init__(self, store: DurableStore, audit: AuditLog, config: DeploymentConfig):
        self.store, self.audit, self.config = store, audit, config

    def validate(self) -> RecoveryReport:
        try:
            self.config.validate()
            # SQLite integrity_check is intentionally required before accepting state.
            row = self.store._db.execute("PRAGMA integrity_check").fetchone()
            db_ok = bool(row and row[0] == "ok")
            if not db_ok:
                raise RecoveryError("database integrity check failed")
            state = self.store.read()
            check_state(state)
            state_ok = True
            audit_ok = self.audit.verify()
            if not audit_ok:
                raise RecoveryError("audit chain verification failed")
            return RecoveryReport(state.version, True, state_ok, True)
        except (RecoveryError, AssertionError, AuditLogError, DeploymentConfigError, ValueError) as exc:
            if isinstance(exc, RecoveryError):
                raise
            raise RecoveryError("startup recovery validation failed") from exc
