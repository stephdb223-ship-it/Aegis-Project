from __future__ import annotations
from dataclasses import dataclass
from .crypto import digest

@dataclass(frozen=True)
class Quorum:
    members: frozenset[str]
    threshold: int

    def __post_init__(self):
        if not self.members:
            raise ValueError("quorum must have members")
        if self.threshold < 1 or self.threshold > len(self.members):
            raise ValueError("invalid quorum threshold")

    def valid(self, signers: set[str])->bool:
        return signers <= self.members and len(signers)>=self.threshold

@dataclass(frozen=True)
class Certificate:
    state_version:int
    epoch:int
    transition_digest:str
    signers:frozenset[str]
    membership_digest:str

def make_certificate(state_version, epoch, transition_digest, signers, quorum):
    if state_version < 1 or epoch < 0 or not transition_digest:
        raise ValueError("invalid certificate fields")
    if not quorum.valid(set(signers)): raise ValueError("invalid quorum")
    return Certificate(state_version,epoch,transition_digest,frozenset(signers),digest(*sorted(quorum.members),str(quorum.threshold)))

def verify_certificate(cert, quorum):
    if cert.state_version < 1 or cert.epoch < 0 or not cert.transition_digest:
        return False
    return (cert.membership_digest==digest(*sorted(quorum.members),str(quorum.threshold)) and
            cert.signers <= quorum.members and len(cert.signers)>=quorum.threshold)
