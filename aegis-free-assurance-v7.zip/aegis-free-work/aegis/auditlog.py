from __future__ import annotations
import json, os
from threading import RLock
try:
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None
from dataclasses import dataclass
from hashlib import sha256
from typing import Mapping

MAX_EVENT_BYTES = 64 * 1024
MAX_FIELD = 4096

@dataclass(frozen=True)
class AuditRecord:
    sequence: int
    event: str
    data: Mapping[str, object]
    previous_hash: str
    record_hash: str

class AuditLogError(ValueError):
    pass

class AuditLog:
    """Append-only JSONL audit log with a tamper-evident hash chain.

    The logger deliberately accepts structured metadata only; callers should never
    put private keys, credentials, tokens, or raw request bodies into `data`.
    """
    def __init__(self, path: str):
        if not path or "\n" in path or "\r" in path:
            raise AuditLogError("invalid audit path")
        self.path = path
        self._lock = RLock()
        parent = os.path.dirname(os.path.abspath(path))
        os.makedirs(parent, exist_ok=True)

    @staticmethod
    def _canonical(obj: object) -> bytes:
        return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()

    def _locked_file(self):
        f = open(self.path, "a+b")
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        return f

    def append(self, event: str, data: Mapping[str, object] | None = None) -> AuditRecord:
        if not event or len(event) > 256 or any(ord(c) < 32 for c in event):
            raise AuditLogError("invalid event")
        payload = dict(data or {})
        if any(len(str(k)) > 256 for k in payload):
            raise AuditLogError("field name too long")
        for k, v in payload.items():
            if isinstance(v, (bytes, bytearray)) or len(str(v)) > MAX_FIELD:
                raise AuditLogError(f"field too large: {k}")
        with self._lock:
            f = self._locked_file()
            try:
                f.seek(0, os.SEEK_END)
                previous = "0" * 64
                sequence = 1
                if f.tell():
                    f.seek(0)
                    last = f.readlines()[-1]
                    obj = json.loads(last)
                    previous = obj["record_hash"]
                    sequence = int(obj["sequence"]) + 1
                body = {"sequence": sequence, "event": event, "data": payload, "previous_hash": previous}
                record_hash = sha256(self._canonical(body)).hexdigest()
                body["record_hash"] = record_hash
                encoded = self._canonical(body) + b"\n"
                if len(encoded) > MAX_EVENT_BYTES:
                    raise AuditLogError("audit event too large")
                f.seek(0, os.SEEK_END)
                f.write(encoded)
                f.flush()
                os.fsync(f.fileno())
                return AuditRecord(sequence, event, payload, previous, record_hash)
            finally:
                if fcntl is not None:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                f.close()

    def verify(self) -> bool:
        previous = "0" * 64
        expected_sequence = 1
        if not os.path.exists(self.path):
            return True
        with open(self.path, "rb") as f:
            for raw in f:
                if not raw.strip():
                    continue
                if len(raw) > MAX_EVENT_BYTES:
                    return False
                try:
                    obj = json.loads(raw)
                    if obj.get("sequence") != expected_sequence or obj.get("previous_hash") != previous:
                        return False
                    supplied = obj.get("record_hash")
                    body = {k: obj[k] for k in ("sequence", "event", "data", "previous_hash")}
                    if sha256(self._canonical(body)).hexdigest() != supplied:
                        return False
                    previous = supplied
                    expected_sequence += 1
                except (UnicodeDecodeError, json.JSONDecodeError, KeyError, TypeError, ValueError):
                    return False
        return True
