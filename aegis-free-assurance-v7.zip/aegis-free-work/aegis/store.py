from __future__ import annotations
from threading import RLock
from dataclasses import replace
from .model import SecurityState

class Conflict(Exception): pass

class AtomicStore:
    def __init__(self, initial: SecurityState|None=None):
        self._state=initial or SecurityState(); self._lock=RLock()
    def read(self):
        with self._lock: return self._state
    def commit(self, expected_version:int, new_state:SecurityState):
        with self._lock:
            if self._state.version!=expected_version: raise Conflict("stale version")
            if new_state.version!=expected_version+1: raise Conflict("non-monotonic commit")
            self._state=new_state
            return self._state
