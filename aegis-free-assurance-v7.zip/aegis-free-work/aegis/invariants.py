from .model import SecurityState
from .crypto import LEVELS

def check_state(s: SecurityState):
    assert s.version>=0 and s.epoch>=0
    assert s.policy.version>=0
    assert LEVELS[s.crypto_level] >= LEVELS[s.policy.min_crypto]
    ids={i.id:i for i in s.identities}
    assert len(ids)==len(s.identities)
    for i in s.identities: assert i.epoch<=s.epoch
    caps={c.id:c for c in s.capabilities}
    assert len(caps)==len(s.capabilities)
    for c in s.capabilities:
        assert c.issuer in ids
        assert c.epoch<=s.epoch
        if c.parent:
            assert c.parent in caps
            p=caps[c.parent]
            assert c.actions <= p.actions
            assert c.resource == p.resource
            assert c.max_depth < p.max_depth
    return True
