from __future__ import annotations
import base64, hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

LEVELS={"classical":0,"hybrid":1,"pqc":2}

def canonical(*parts: str|bytes)->bytes:
    out=[]
    for p in parts:
        b=p if isinstance(p,bytes) else p.encode()
        out.append(len(b).to_bytes(8,"big")+b)
    return b"AEGIS\x00"+b"".join(out)

def digest(*parts: str|bytes)->str:
    return hashlib.sha256(canonical(*parts)).hexdigest()

def sign_context(private: Ed25519PrivateKey, domain: str, payload: bytes)->str:
    return base64.b64encode(private.sign(canonical(domain,payload))).decode()

def verify_context(public: Ed25519PublicKey, domain: str, payload: bytes, signature: str)->bool:
    try:
        public.verify(base64.b64decode(signature), canonical(domain,payload)); return True
    except (InvalidSignature, ValueError): return False
