from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Sequence
import random

@dataclass(frozen=True)
class Failure:
    seed: int
    step: int
    action: str
    message: str

@dataclass(frozen=True)
class EnduranceResult:
    seed: int
    steps: int
    digest: str

class SequenceMinimizer:
    """Deterministic delta-debugger for short reproducing action sequences."""
    def __init__(self, fails: Callable[[Sequence[str]], bool]):
        self.fails = fails

    def minimize(self, sequence: Sequence[str]) -> list[str]:
        current = list(sequence)
        if not self.fails(current):
            raise ValueError("sequence does not reproduce failure")
        granularity = 2
        while len(current) >= 2:
            chunk = max(1, (len(current) + granularity - 1) // granularity)
            reduced = False
            start = 0
            while start < len(current):
                candidate = current[:start] + current[min(len(current), start + chunk):]
                if candidate and self.fails(candidate):
                    current = candidate
                    granularity = max(2, granularity - 1)
                    reduced = True
                    break
                start += chunk
            if not reduced:
                if granularity >= len(current):
                    break
                granularity = min(len(current), granularity * 2)
        return current

class DeterministicEndurance:
    """Generic deterministic campaign runner with reproducible action traces."""
    def __init__(self, seed: int):
        self.seed = seed
        self.rng = random.Random(seed)
        self.history: list[str] = []

    def choose(self, labels: Sequence[str]) -> str:
        action = labels[self.rng.randrange(len(labels))]
        self.history.append(action)
        return action

    def digest_history(self) -> str:
        import hashlib
        h = hashlib.sha256()
        for item in self.history:
            b = item.encode("utf-8")
            h.update(len(b).to_bytes(4, "big"))
            h.update(b)
        return h.hexdigest()
