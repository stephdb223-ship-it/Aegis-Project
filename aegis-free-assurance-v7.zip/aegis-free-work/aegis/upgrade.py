from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Mapping

class UpgradeError(ValueError):
    pass

@dataclass(frozen=True, order=True)
class ReleaseVersion:
    major: int
    minor: int
    patch: int

    @classmethod
    def parse(cls, value: str) -> "ReleaseVersion":
        parts = value.split(".")
        if len(parts) != 3 or any(not p.isdigit() for p in parts):
            raise UpgradeError("release version must be MAJOR.MINOR.PATCH")
        v = cls(*(int(p) for p in parts))
        if any(x < 0 or x > 1_000_000 for x in (v.major, v.minor, v.patch)):
            raise UpgradeError("release version component out of range")
        return v

@dataclass(frozen=True)
class StateEnvelope:
    schema_version: int
    release: ReleaseVersion
    state_version: int

    def validate(self) -> None:
        if self.schema_version < 1:
            raise UpgradeError("invalid schema version")
        if self.state_version < 0:
            raise UpgradeError("invalid state version")

def validate_upgrade(current: StateEnvelope, target: StateEnvelope) -> None:
    current.validate(); target.validate()
    if target.schema_version < current.schema_version:
        raise UpgradeError("schema rollback is forbidden")
    if target.release < current.release:
        raise UpgradeError("software rollback requires a forward-compatible state plan")
    if target.state_version < current.state_version:
        raise UpgradeError("security state version rollback is forbidden")
    if target.schema_version > current.schema_version + 1:
        raise UpgradeError("skipping schema versions is forbidden")

def migrate_state(payload: Mapping[str, object], current_schema: int, target_schema: int,
                  migrations: Mapping[int, Callable[[dict], dict]]) -> dict:
    if current_schema < 1 or target_schema < current_schema:
        raise UpgradeError("invalid migration range")
    if target_schema > current_schema + 1:
        raise UpgradeError("migrations must be applied one schema version at a time")
    data = dict(payload)
    if target_schema == current_schema:
        return data
    fn = migrations.get(current_schema)
    if fn is None:
        raise UpgradeError(f"missing migration {current_schema}->{target_schema}")
    out = fn(dict(data))
    if not isinstance(out, dict):
        raise UpgradeError("migration must return a dict")
    return out

class UpgradeGuard:
    """Fail-closed gate for deployment upgrades; never rewinds security state."""
    def __init__(self, current: StateEnvelope):
        current.validate()
        self.current = current

    def approve(self, target: StateEnvelope) -> StateEnvelope:
        validate_upgrade(self.current, target)
        self.current = target
        return target
