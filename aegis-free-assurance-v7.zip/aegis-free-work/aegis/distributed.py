from __future__ import annotations
from dataclasses import dataclass, field
from collections import defaultdict
from .crypto import digest
from .quorum import Quorum, Certificate, make_certificate, verify_certificate

@dataclass(frozen=True)
class Statement:
    signer: str
    state_version: int
    epoch: int
    transition_digest: str

@dataclass(frozen=True)
class Commit:
    certificate: Certificate
    state_digest: str

@dataclass
class Replica:
    replica_id: str
    committed: list[Commit] = field(default_factory=list)
    seen_messages: set[str] = field(default_factory=set)
    quarantined: set[str] = field(default_factory=set)

    def accept(self, commit: Commit, quorum: Quorum) -> bool:
        if not verify_certificate(commit.certificate, quorum):
            return False
        key = digest(str(commit.certificate.state_version), str(commit.certificate.epoch),
                     commit.certificate.transition_digest, commit.certificate.membership_digest)
        if key in self.seen_messages:
            return True
        self.seen_messages.add(key)
        if self.committed and commit.certificate.state_version < self.committed[-1].certificate.state_version:
            return False
        self.committed.append(commit)
        return True

class DistributedSimulator:
    """Deterministic model of quorum delivery, duplication, reordering and equivocation.

    This is deliberately separate from Aegis' durable store: it tests distributed
    safety properties without pretending to be a production consensus protocol.
    """
    def __init__(self, members: set[str], threshold: int):
        self.quorum = Quorum(frozenset(members), threshold)
        self.replicas = {m: Replica(m) for m in members}
        self.statements: dict[tuple[str,int,int], set[str]] = defaultdict(set)
        self.equivocations: set[str] = set()

    def statement(self, signer: str, state_version: int, epoch: int, transition_digest: str):
        if signer not in self.quorum.members:
            raise ValueError("unknown signer")
        key = (signer, state_version, epoch)
        previous = self.statements[key]
        if previous and transition_digest not in previous:
            self.equivocations.add(signer)
        previous.add(transition_digest)
        return Statement(signer, state_version, epoch, transition_digest)

    def certificate(self, state_version: int, epoch: int, transition_digest: str, signers: set[str]) -> Certificate:
        if self.equivocations.intersection(signers):
            raise ValueError("equivocating signer cannot certify")
        return make_certificate(state_version, epoch, transition_digest, signers, self.quorum)

    def broadcast(self, commit: Commit, recipients: set[str] | None = None) -> int:
        recipients = set(self.replicas) if recipients is None else set(recipients)
        accepted = 0
        for rid in recipients:
            if self.replicas[rid].accept(commit, self.quorum):
                accepted += 1
        return accepted

    def finality(self, state_version: int, epoch: int) -> dict[str, str]:
        result = {}
        for rid, replica in self.replicas.items():
            candidates = [c for c in replica.committed
                          if c.certificate.state_version == state_version and c.certificate.epoch == epoch]
            digests = {c.certificate.transition_digest for c in candidates}
            if len(digests) == 1:
                result[rid] = next(iter(digests))
            elif len(digests) > 1:
                result[rid] = "CONFLICT"
        return result
