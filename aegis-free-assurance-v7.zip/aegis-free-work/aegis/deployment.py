from __future__ import annotations
from dataclasses import dataclass
import ipaddress
import os
import re
from typing import Mapping

class DeploymentConfigError(ValueError):
    pass

@dataclass(frozen=True)
class DeploymentConfig:
    environment: str
    bind_host: str
    bind_port: int
    audit_log: str
    max_request_bytes: int = 1_048_576
    request_timeout_ms: int = 5_000
    require_tls: bool = True
    allow_debug: bool = False

    @classmethod
    def from_mapping(cls, raw: Mapping[str, object]) -> "DeploymentConfig":
        allowed = {"environment","bind_host","bind_port","audit_log","max_request_bytes","request_timeout_ms","require_tls","allow_debug"}
        unknown = set(raw) - allowed
        if unknown: raise DeploymentConfigError(f"unknown settings: {sorted(unknown)}")
        try:
            cfg = cls(
                environment=str(raw["environment"]), bind_host=str(raw["bind_host"]),
                bind_port=int(raw["bind_port"]), audit_log=str(raw["audit_log"]),
                max_request_bytes=int(raw.get("max_request_bytes", 1_048_576)),
                request_timeout_ms=int(raw.get("request_timeout_ms", 5_000)),
                require_tls=bool(raw.get("require_tls", True)), allow_debug=bool(raw.get("allow_debug", False)),
            )
        except (KeyError, TypeError, ValueError) as e:
            raise DeploymentConfigError("invalid deployment configuration") from e
        cfg.validate(); return cfg

    def validate(self) -> None:
        if self.environment not in {"development","staging","production"}: raise DeploymentConfigError("invalid environment")
        if not (1 <= self.bind_port <= 65535): raise DeploymentConfigError("invalid port")
        if self.max_request_bytes < 1024 or self.max_request_bytes > 16 * 1024 * 1024: raise DeploymentConfigError("unsafe request limit")
        if self.request_timeout_ms < 100 or self.request_timeout_ms > 120_000: raise DeploymentConfigError("unsafe request timeout")
        if not self.audit_log or os.path.isabs(self.audit_log) and not self.audit_log.startswith("/var/log/aegis/"):
            raise DeploymentConfigError("audit log path must be controlled")
        try: ipaddress.ip_address(self.bind_host)
        except ValueError:
            if not re.fullmatch(r"[A-Za-z0-9_.-]+", self.bind_host): raise DeploymentConfigError("invalid bind host")
        if self.environment == "production" and self.allow_debug: raise DeploymentConfigError("debug disabled in production")
        if self.environment == "production" and not self.require_tls: raise DeploymentConfigError("TLS required in production")


def validate_environment(env: Mapping[str, str]) -> None:
    forbidden = {k for k in env if k.upper().startswith(("AEGIS_DEBUG","AEGIS_DEV_")) and env[k] not in ("","0","false","False")}
    if forbidden: raise DeploymentConfigError(f"unsafe environment flags: {sorted(forbidden)}")
