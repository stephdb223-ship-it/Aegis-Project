from __future__ import annotations
import random
from dataclasses import replace
from .distributed import DistributedSimulator, Commit
from .protocol import encode_commit, decode_commit, message_id
from .quorum import make_certificate
from .crypto import digest

class CrossModuleCampaign:
    """Deterministic integration campaign spanning wire, quorum and replicas.

    This is a model-level test harness, not a production consensus implementation.
    """
    def __init__(self, seed: int, members: tuple[str, ...] = ("n1", "n2", "n3", "n4", "n5")):
        self.rng = random.Random(seed)
        self.sim = DistributedSimulator(set(members), 3)
        self.version = 0
        self.epoch = 0
        self.last_digest = digest("root")
        self.ids: set[str] = set()

    def step(self) -> None:
        action = self.rng.randrange(6)
        if action <= 2:
            candidate_version = self.version + 1
            td = digest(self.last_digest, str(candidate_version), str(self.epoch), str(self.rng.randrange(1 << 32)))
            signers = set(self.rng.sample(sorted(self.sim.quorum.members), 3))
            try:
                cert = self.sim.certificate(candidate_version, self.epoch, td, signers)
            except ValueError:
                cert = None
            if cert is None:
                return self._assert_safety()
            self.version = candidate_version
            commit = Commit(cert, digest(td, str(self.version)))
            wire = encode_commit(commit)
            decoded = decode_commit(wire)
            assert decoded == commit
            assert message_id(wire) == message_id(encode_commit(decoded))
            recipients = set(self.rng.sample(sorted(self.sim.replicas), self.rng.randint(1, 5)))
            self.sim.broadcast(decoded, recipients)
            self.last_digest = td
        elif action == 3:
            rid = self.rng.choice(sorted(self.sim.replicas))
            r = self.sim.replicas[rid]
            if r.committed:
                wire = encode_commit(r.committed[-1])
                assert decode_commit(wire) == r.committed[-1]
                self.sim.broadcast(decode_commit(wire), {rid})
        elif action == 4:
            rid = self.rng.choice(sorted(self.sim.replicas))
            r = self.sim.replicas[rid]
            if r.committed:
                c = r.committed[-1]
                obj = replace(c, state_digest=digest(c.state_digest, "mutated"))
                wire = encode_commit(obj)
                assert decode_commit(wire) == obj
                # Same certificate but a different state digest is not allowed to
                # create a second authoritative transition at the same version.
                assert self.sim.finality(c.certificate.state_version, c.certificate.epoch).get(rid) == c.certificate.transition_digest
        else:
            signer = self.rng.choice(sorted(self.sim.quorum.members))
            base = digest(self.last_digest, str(self.version), str(self.epoch))
            self.sim.statement(signer, self.version, self.epoch, base + "a")
            self.sim.statement(signer, self.version, self.epoch, base + "b")
            try:
                self.sim.certificate(self.version + 1, self.epoch, digest(base, "next"), {signer, *set(self.rng.sample(sorted(self.sim.quorum.members - {signer}), 2))})
            except ValueError:
                pass

        self._assert_safety()

    def _assert_safety(self):
        for replica in self.sim.replicas.values():
            versions = [x.certificate.state_version for x in replica.committed]
            assert versions == sorted(versions)
            assert len(versions) == len(set(versions))
            for commit in replica.committed:
                wire = encode_commit(commit)
                assert decode_commit(wire) == commit

    def run(self, steps: int = 5000) -> int:
        for _ in range(steps):
            self.step()
        return steps
