"""Concrete NIST-standardized PQC provider backed by OpenSSL 3.5+.

This adapter deliberately shells out to the local OpenSSL binary. It is a
reference/integration provider, not a claim of FIPS 140 validation or a
production deployment recommendation.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass

from .pqc import PQCProvider, PQCProviderError


def _run(args: list[str], *, cwd: str | None = None) -> bytes:
    try:
        p = subprocess.run(args, cwd=cwd, check=True, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=10)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        raise PQCProviderError(f"OpenSSL unavailable: {exc}") from exc
    except subprocess.CalledProcessError as exc:
        detail = exc.stderr.decode(errors="replace").strip()
        raise PQCProviderError(f"OpenSSL operation failed: {detail}") from exc
    return p.stdout


def openssl_pqc_available(algorithm: str) -> bool:
    exe = shutil.which("openssl")
    if not exe:
        return False
    try:
        out = subprocess.run([exe, "list", "-signature-algorithms"],
                             check=True, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, timeout=5).stdout.decode()
        return algorithm in out
    except (OSError, subprocess.SubprocessError):
        return False


def openssl_kem_available(algorithm: str) -> bool:
    exe = shutil.which("openssl")
    if not exe:
        return False
    try:
        out = subprocess.run([exe, "list", "-kem-algorithms"],
                             check=True, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, timeout=5).stdout.decode()
        return algorithm in out
    except (OSError, subprocess.SubprocessError):
        return False


@dataclass
class OpenSSLMLDSAProvider(PQCProvider):
    """ML-DSA provider using OpenSSL's FIPS-204 implementation."""

    parameter_set: str = "ML-DSA-65"
    context_string: str = "AEGIS/protocol/v1"
    name: str = "openssl-ml-dsa-65"
    algorithm: str = "ML-DSA-65"
    security_level: int = 3
    production: bool = True

    def __post_init__(self) -> None:
        if self.parameter_set != self.algorithm:
            raise PQCProviderError("parameter set/algorithm mismatch")
        if not openssl_pqc_available(self.algorithm):
            raise PQCProviderError(f"OpenSSL does not expose {self.algorithm}")
        self._tmp = tempfile.TemporaryDirectory(prefix="aegis-mldsa-")
        self._sk = os.path.join(self._tmp.name, "sk.pem")
        self._pk = os.path.join(self._tmp.name, "pk.pem")
        exe = shutil.which("openssl")
        assert exe
        _run([exe, "genpkey", "-algorithm", self.algorithm, "-out", self._sk])
        _run([exe, "pkey", "-in", self._sk, "-pubout", "-out", self._pk])

    def close(self) -> None:
        self._tmp.cleanup()

    def sign(self, message: bytes) -> bytes:
        msg = os.path.join(self._tmp.name, "message")
        sig = os.path.join(self._tmp.name, "signature")
        with open(msg, "wb") as f:
            f.write(message)
        exe = shutil.which("openssl")
        assert exe
        _run([exe, "pkeyutl", "-sign", "-inkey", self._sk,
              "-in", msg, "-out", sig, "-pkeyopt", f"context-string:{self.context_string}"])
        return open(sig, "rb").read()

    def verify(self, message: bytes, signature: bytes) -> bool:
        msg = os.path.join(self._tmp.name, "message")
        sig = os.path.join(self._tmp.name, "signature")
        with open(msg, "wb") as f:
            f.write(message)
        with open(sig, "wb") as f:
            f.write(signature)
        exe = shutil.which("openssl")
        assert exe
        try:
            _run([exe, "pkeyutl", "-verify", "-pubin", "-inkey", self._pk,
                  "-in", msg, "-sigfile", sig, "-pkeyopt", f"context-string:{self.context_string}"])
            return True
        except PQCProviderError:
            return False


@dataclass
class OpenSSLMLKEMProvider:
    """ML-KEM provider using OpenSSL's FIPS-203 implementation."""

    parameter_set: str = "ML-KEM-768"
    name: str = "openssl-ml-kem-768"
    algorithm: str = "ML-KEM-768"
    security_level: int = 3
    production: bool = True

    def __post_init__(self) -> None:
        if self.parameter_set != self.algorithm:
            raise PQCProviderError("parameter set/algorithm mismatch")
        if not openssl_kem_available(self.algorithm):
            raise PQCProviderError(f"OpenSSL does not expose {self.algorithm}")
        self._tmp = tempfile.TemporaryDirectory(prefix="aegis-mlkem-")
        self._sk = os.path.join(self._tmp.name, "sk.pem")
        self._pk = os.path.join(self._tmp.name, "pk.pem")
        exe = shutil.which("openssl")
        assert exe
        _run([exe, "genpkey", "-algorithm", self.algorithm, "-out", self._sk])
        _run([exe, "pkey", "-in", self._sk, "-pubout", "-out", self._pk])

    def close(self) -> None:
        self._tmp.cleanup()

    def encapsulate(self) -> tuple[bytes, bytes]:
        ct = os.path.join(self._tmp.name, "ciphertext")
        secret = os.path.join(self._tmp.name, "secret")
        exe = shutil.which("openssl")
        assert exe
        _run([exe, "pkeyutl", "-encap", "-pubin", "-inkey", self._pk,
              "-out", ct, "-secret", secret])
        return open(ct, "rb").read(), open(secret, "rb").read()

    def decapsulate(self, ciphertext: bytes) -> bytes:
        ct = os.path.join(self._tmp.name, "ciphertext-input")
        secret = os.path.join(self._tmp.name, "secret-output")
        with open(ct, "wb") as f:
            f.write(ciphertext)
        exe = shutil.which("openssl")
        assert exe
        _run([exe, "pkeyutl", "-decap", "-inkey", self._sk,
              "-in", ct, "-secret", secret])
        return open(secret, "rb").read()
