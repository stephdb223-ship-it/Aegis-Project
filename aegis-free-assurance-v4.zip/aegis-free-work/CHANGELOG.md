# Changelog

## 0.2.0-review

Security-assurance baseline for independent review, including protocol hardening,
distributed-failure testing, crash recovery, key lifecycle controls, audit-chain
integrity, deployment validation, deterministic endurance campaigns, and review
traceability.

This release candidate is **not** a certification and has not received an
independent third-party security audit.
