import pytest
from aegis.pqc import PQCProviderError
from aegis.pqc_openssl import (
    OpenSSLMLDSAProvider, OpenSSLMLKEMProvider,
    openssl_pqc_available, openssl_kem_available,
)


def test_openssl_mldsa_is_available_and_round_trips():
    if not openssl_pqc_available("ML-DSA-65"):
        pytest.skip("OpenSSL ML-DSA-65 unavailable")
    p = OpenSSLMLDSAProvider()
    try:
        msg = b"AEGIS/FIPS-204/context/v1"
        sig = p.sign(msg)
        assert p.verify(msg, sig)
        assert not p.verify(msg + b"!", sig)
        assert p.production
        assert p.security_level == 3
    finally:
        p.close()


def test_openssl_mlkem_is_available_and_round_trips():
    if not openssl_kem_available("ML-KEM-768"):
        pytest.skip("OpenSSL ML-KEM-768 unavailable")
    p = OpenSSLMLKEMProvider()
    try:
        ciphertext, secret = p.encapsulate()
        assert len(ciphertext) > 0
        assert len(secret) >= 32
        assert p.decapsulate(ciphertext) == secret
        with pytest.raises(PQCProviderError):
            p.decapsulate(ciphertext[:-1])
    finally:
        p.close()
